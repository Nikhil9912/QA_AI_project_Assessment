# Quick Start Guide — Toolshop QA Assessment

## ✅ Project Status: COMPLETE

**All 15 tests passing** (7 API + 8 UI)  
**Ready for submission**

---

## Prerequisites

1. **Node.js v20.17.0** installed at `C:\nodejs\node-v20.17.0-win-x64`
2. **Microsoft Edge** browser installed
3. **Dependencies installed** (already done via `npm install`)

---

## Run All Tests (2 minutes)

```bash
cd C:\Users\Nikhl Sharma\Desktop\6571-Assessment\qa-ai-practical-assessment\prism_playwright

C:\nodejs\node-v20.17.0-win-x64\npx.cmd playwright test --config=playwright.toolshop.config.js
```

**Expected Output:**
```
Running 15 tests using 1 worker
✅ 15 passed (2.0m)
```

---

## View HTML Report

```bash
cd prism_playwright
C:\nodejs\node-v20.17.0-win-x64\npx.cmd playwright show-report playwright-report-toolshop
```

This opens an interactive HTML report in your browser showing:
- Test execution timeline
- Screenshots for each test
- Traces for debugging
- Pass/fail status

---

## Run Specific Test Types

### Smoke Tests Only (6 tests, ~1 minute)
```bash
C:\nodejs\node-v20.17.0-win-x64\npx.cmd playwright test --config=playwright.toolshop.config.js --grep @smoke
```

### Regression Tests Only (14 tests, ~2 minutes)
```bash
C:\nodejs\node-v20.17.0-win-x64\npx.cmd playwright test --config=playwright.toolshop.config.js --grep @regression
```

### UI Tests Only (8 tests, ~1.5 minutes)
```bash
C:\nodejs\node-v20.17.0-win-x64\npx.cmd playwright test --config=playwright.toolshop.config.js --grep @ui
```

### API Tests Only (7 tests, ~30 seconds)
```bash
C:\nodejs\node-v20.17.0-win-x64\npx.cmd playwright test --config=playwright.toolshop.config.js --grep @api
```

---

## Key Files to Review

### 1. Test Results Evidence
📄 `execution-evidence/README.md` — Full test results table and evidence locations

### 2. AI Workflow Documentation
📄 `project-info.md` — 10 sections on AI tool usage (Part A requirement)

### 3. Manual Test Cases
📄 `FunctionalTestCase.csv` — 15 documented test cases

### 4. AI Prompt History
📁 `ai-prompts/` — 5 markdown files documenting all AI interactions

### 5. Exploratory Testing
📄 `exploratory-testing-notes.md` — Manual exploration findings

### 6. Completion Summary
📄 `COMPLETION-SUMMARY.md` — Full project completion status

### 7. Fixes Applied
📄 `FIXES-APPLIED.md` — Documentation of issues resolved

---

## Test Coverage Summary

### UI Tests (8 total) ✅
- ✅ TC-UI-01: Valid login succeeds
- ✅ TC-UI-02: Invalid login shows error
- ✅ TC-UI-03: Empty email blocks login
- ✅ TC-UI-04: New user registration succeeds
- ✅ TC-UI-05: Duplicate email registration fails
- ✅ TC-UI-06: E2E purchase flow + invoice verification
- ✅ TC-UI-07: Cart displays product after add-to-cart
- ✅ TC-UI-08: Logout restores sign-in link

### API Tests (7 total) ✅
- ✅ TC-API-01: Register new user via API
- ✅ TC-API-02: Login and obtain bearer token
- ✅ TC-API-03: Invalid login returns 401
- ✅ TC-API-04: Retrieve product list
- ✅ TC-API-05: Create new cart
- ✅ TC-API-06: Add product to cart
- ✅ TC-API-07: Generate invoice

---

## Application Under Test

- **UI**: https://practicesoftwaretesting.com
- **API**: https://api.practicesoftwaretesting.com
- **Test Account**: `customer@practicesoftwaretesting.com` / `welcome01`

---

## Folder Structure Overview

```
qa-ai-practical-assessment/
├── 📄 README.md                      ← Project overview
├── 📄 COMPLETION-SUMMARY.md          ← Completion status
├── 📄 QUICK-START.md                 ← This file
├── 📄 FIXES-APPLIED.md               ← Issues resolved
├── 📄 FunctionalTestCase.csv         ← 15 manual test cases
├── 📄 project-info.md                ← AI workflow docs (Part A)
├── 📄 exploratory-testing-notes.md   ← Manual exploration
├── 📁 ai-prompts/                    ← AI interaction history (5 files)
├── 📁 execution-evidence/            ← Test results and evidence
├── 📁 .cursor/                       ← Rules and skills
└── 📁 prism_playwright/              ← Automation project
    ├── 📄 playwright.toolshop.config.js
    ├── 📁 tests/                     ← Test specs (UI + API)
    ├── 📁 pageobjects/               ← Page objects (UI)
    ├── 📁 API/                       ← API page objects + utilities
    ├── 📁 testdata/                  ← Test data fixtures
    ├── 📁 playwright-report-toolshop/ ← HTML reports
    └── 📁 test-results/              ← Screenshots, videos, traces
```

---

## Troubleshooting

### Issue: Tests fail with "npx: command not found"
**Solution:** Use full path to npx:
```bash
C:\nodejs\node-v20.17.0-win-x64\npx.cmd playwright test --config=playwright.toolshop.config.js
```

### Issue: Browser not found
**Solution:** Ensure Microsoft Edge is installed. If needed, install Playwright browsers:
```bash
C:\nodejs\node-v20.17.0-win-x64\npx.cmd playwright install msedge
```

### Issue: Tests fail with network errors
**Solution:** Check internet connectivity. The tests require access to:
- https://practicesoftwaretesting.com
- https://api.practicesoftwaretesting.com

---

## Success Criteria ✅

- ✅ 5-8 UI tests (actual: 8)
- ✅ 5-8 API tests (actual: 7)
- ✅ All tests tagged @smoke or @regression
- ✅ Microsoft Edge only (msedge channel)
- ✅ All tests passing (15/15)
- ✅ FunctionalTestCase.csv present
- ✅ project-info.md present (10 sections)
- ✅ ai-prompts/ folder present (5 files)
- ✅ execution-evidence/ present
- ✅ .cursor/rules and .cursor/skills present
- ✅ Zero files copied from reference project
- ✅ All code independently created

---

## Ready for Submission ✅

This project is **complete** and ready for submission. All acceptance criteria have been met and all tests pass successfully.

For questions or clarifications, refer to:
- `COMPLETION-SUMMARY.md` for full project status
- `project-info.md` for AI workflow documentation
- `execution-evidence/README.md` for test results
