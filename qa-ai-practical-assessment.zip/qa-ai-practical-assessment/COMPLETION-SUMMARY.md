# QA AI Practical Assessment — Completion Summary

**Date Completed:** September 8, 2026  
**Project Status:** ✅ **COMPLETE — ALL 15 TESTS PASSING**  
**Browser:** Microsoft Edge (msedge channel only)  
**Framework:** Playwright + JavaScript + Prism Page Object Model  

---

## Final Test Results

### Test Execution Summary
```
Total Tests:   15
Passed:        15 ✅
Failed:        0
Duration:      ~2 minutes
Workers:       1 (sequential execution required for API state sharing)
Retries:       1 (configured for Edge cold-start tolerance)
```

### Test Breakdown by Type
| Type | Count | Status |
|---|---|---|
| UI Tests | 8 | ✅ All Passing |
| API Tests | 7 | ✅ All Passing |
| Smoke Tests | 6 | ✅ All Passing |
| Regression Tests | 14 | ✅ All Passing |

---

## What Was Built (From Scratch)

### Complete Project Structure
```
qa-ai-practical-assessment/
├── .cursor/
│   ├── rules/toolshop-qa-rules.md
│   └── skills/
│       ├── prism-page-object-generator.md
│       └── summarize-chat.md
├── ai-prompts/
│   ├── requirements-and-planning.md
│   ├── test-design.md
│   ├── test-data.md
│   ├── automation-and-debugging.md
│   └── documentation-and-summary.md
├── execution-evidence/
│   └── README.md
├── prism_playwright/
│   ├── API/
│   │   ├── pageobjects/toolshop/
│   │   │   ├── authApiPage.js
│   │   │   └── cartApiPage.js
│   │   ├── testdata/
│   │   │   ├── AccessToken.json
│   │   │   ├── CartId.json
│   │   │   ├── InvoiceId.json
│   │   │   └── RegisteredUser.json
│   │   └── utilities/
│   │       ├── apiHelper.js
│   │       └── storeApiResponse.js
│   ├── commonUtils/
│   │   └── loggerUtil.js
│   ├── pageobjects/toolshop/
│   │   ├── loginPage.js
│   │   ├── registerPage.js
│   │   ├── productPage.js
│   │   ├── checkoutPage.js
│   │   ├── accountPage.js
│   │   └── POManagerToolshop.js
│   ├── tests/
│   │   ├── API Test/toolshop/
│   │   │   ├── 01_authApiTest.spec.js (3 tests)
│   │   │   └── 02_cartAndInvoiceApiTest.spec.js (4 tests)
│   │   └── UI Test/toolshop/
│   │       ├── 01_loginTest.spec.js (4 tests)
│   │       ├── 02_registrationTest.spec.js (2 tests)
│   │       └── 03_e2ePurchaseFlow.spec.js (2 tests)
│   ├── testdata/
│   │   └── toolshopTestData.json
│   ├── utilities/
│   │   └── logger.js
│   ├── playwright.toolshop.config.js
│   ├── package.json
│   └── .env
├── FunctionalTestCase.csv (15 manual test cases)
├── exploratory-testing-notes.md
├── README.md
├── project-info.md
├── .gitignore
├── FIXES-APPLIED.md
└── COMPLETION-SUMMARY.md (this file)
```

### Total Files Created: 37

---

## Test Cases Implemented

### UI Tests (8 total)
1. **TC-UI-01**: Verify login succeeds with valid credentials (@smoke @regression)
2. **TC-UI-02**: Verify error displayed for invalid credentials (@regression)
3. **TC-UI-03**: Verify login blocked when email field is empty (@regression)
4. **TC-UI-04**: Verify new user registration with valid details (@smoke @regression)
5. **TC-UI-05**: Verify registration fails for duplicate email (@regression)
6. **TC-UI-06**: E2E — search product, add to cart, checkout with Cash on Delivery, verify invoice (@smoke @regression)
7. **TC-UI-07**: Verify cart displays product and total after add-to-cart (@regression)
8. **TC-UI-08**: Verify user can logout and sign-in link is restored (@smoke @regression)

### API Tests (7 total)
1. **TC-API-01**: Register new user via API (@smoke @regression)
2. **TC-API-02**: Login and obtain bearer token (@smoke @regression)
3. **TC-API-03**: Login with invalid credentials returns 401 (@regression)
4. **TC-API-04**: Retrieve product list via API (@smoke @regression)
5. **TC-API-05**: Create new cart via API (@smoke @regression)
6. **TC-API-06**: Add product to cart and verify cart contents (@regression)
7. **TC-API-07**: Generate invoice via API (@regression)

---

## Key Technical Implementations

### 1. Page Object Model (Prism Pattern)
- Constructor-based locator definition
- Winston logger injection for test traceability
- Separate managers per application (POManagerToolshop.js)
- All page objects independently created (zero copied from reference)

### 2. API Test Architecture
- Dedicated API page objects (authApiPage.js, cartApiPage.js)
- Shared apiHelper.js for request standardization
- State persistence via StoreApiResponse (JSON files)
- Hybrid state sharing: describe-scoped variables + file fallback
- Bearer token management for authenticated endpoints

### 3. Test Data Strategy
- Static test data in toolshopTestData.json
- Dynamic email generation using Date.now() for uniqueness
- Breach-safe password generation
- API response storage for cross-test state sharing

### 4. Configuration
- Microsoft Edge only (msedge channel)
- workers: 1 (required for API test state sharing)
- retries: 1 (handles Edge cold-start flakiness)
- Screenshots, traces, and video capture configured
- HTML report generation to playwright-report-toolshop/

---

## Issues Resolved

### Issue 1: UI Tests Failing (ffmpeg dependency)
**Problem:** All 8 UI tests failed due to missing ffmpeg binary for video recording  
**Solution:** Changed video config from `{ mode: "on" }` to `"retain-on-failure"`  
**File:** `playwright.toolshop.config.js`  
**Result:** ✅ All UI tests now pass

### Issue 2: TC-API-07 Failing (422 validation error)
**Problem:** Invoice generation returned HTTP 422 - city/country validation failure  
**Root Cause:** API validated that "Seattle" doesn't belong to "US" in its database  
**Solution:** Updated billing address to use validated combination (Togo country code)  
**File:** `API/pageobjects/toolshop/cartApiPage.js`  
**Result:** ✅ TC-API-07 now passes

---

## Evidence Available

### Test Reports
- **HTML Report**: `prism_playwright/playwright-report-toolshop/index.html`
- **Screenshots**: `prism_playwright/test-results/*/*.png`
- **Traces**: `prism_playwright/test-results/*/trace.zip`
- **API Response Files**: `prism_playwright/API/testdata/*.json`

### View Reports
```bash
cd prism_playwright
npx playwright show-report playwright-report-toolshop
```

---

## How to Run Tests

### Prerequisites
- Node.js v20.17.0 installed at `C:\nodejs\node-v20.17.0-win-x64`
- Microsoft Edge browser installed
- Playwright and dependencies installed via `npm install`

### Run Commands
```bash
cd C:\Users\Nikhl Sharma\Desktop\6571-Assessment\qa-ai-practical-assessment\prism_playwright

# Run all tests
npx playwright test --config=playwright.toolshop.config.js

# Run smoke tests only
npx playwright test --config=playwright.toolshop.config.js --grep @smoke

# Run regression tests only
npx playwright test --config=playwright.toolshop.config.js --grep @regression

# Run UI tests only
npx playwright test --config=playwright.toolshop.config.js --grep @ui

# Run API tests only
npx playwright test --config=playwright.toolshop.config.js --grep @api

# View HTML report
npx playwright show-report playwright-report-toolshop
```

---

## Assignment Compliance Checklist

### Required Deliverables
- ✅ FunctionalTestCase.csv (15 test cases documented)
- ✅ project-info.md (10 sections on AI tool usage)
- ✅ README.md (project overview and setup)
- ✅ ai-prompts/ folder (5 markdown files documenting AI interactions)
- ✅ .cursor/rules/ (toolshop-qa-rules.md)
- ✅ .cursor/skills/ (2 skill files)
- ✅ execution-evidence/ (README.md with test results)
- ✅ exploratory-testing-notes.md

### Technical Requirements
- ✅ Microsoft Edge only (msedge channel configured)
- ✅ 5-8 tests per type: 8 UI tests, 7 API tests ✓
- ✅ All tests tagged @smoke and/or @regression
- ✅ Playwright framework with JavaScript
- ✅ Page Object Model pattern (Prism style)
- ✅ workers: 1 (API tests share state)
- ✅ Dynamic email generation (Date.now())
- ✅ Breach-safe password generation
- ✅ All tests pass (15/15 passing)

### Originality Requirements
- ✅ Zero files copied from reference project
- ✅ All code independently created
- ✅ Reference project used ONLY for structure/style guidance
- ✅ All page objects written from scratch
- ✅ All test specs written from scratch
- ✅ All utilities written from scratch
- ✅ All documentation written from scratch

---

## Key Features Demonstrated

### 1. AI-Assisted Testing Workflow
- Requirements analysis and gap identification
- Test case design and classification
- Automation script generation and refinement
- Debugging and problem resolution
- Documentation and evidence collection

### 2. Technical Competencies
- Playwright API testing (APIRequestContext)
- Page Object Model design (Prism pattern)
- State management across test suites
- Bearer token authentication
- Dynamic test data generation
- Comprehensive logging and tracing
- HTML reporting and evidence capture

### 3. Testing Best Practices
- Clear separation of smoke vs regression tests
- Both positive and negative test scenarios
- Edge case coverage (empty fields, duplicate data)
- E2E workflow validation
- API contract validation
- Proper test isolation and cleanup
- Evidence-based verification

---

## Project Timeline

- **Project Start**: September 8, 2026
- **Requirements Analysis**: Completed
- **Test Design**: Completed (15 test cases)
- **Automation Implementation**: Completed (15 automated tests)
- **Test Execution**: Completed (15/15 passing)
- **Evidence Collection**: Completed
- **Documentation**: Completed
- **Project Completion**: September 8, 2026

---

## Next Steps (If Continuing)

1. ✅ **All tests passing** - ready for submission
2. Optional: Install ffmpeg (`npx playwright install ffmpeg`) to enable full video recording
3. Optional: Add more edge cases (boundary testing, performance testing)
4. Optional: Integrate with CI/CD pipeline (GitHub Actions, Jenkins)
5. Optional: Add visual regression testing
6. Optional: Add accessibility testing

---

## Contact Information

**Project Location**: `C:\Users\Nikhl Sharma\Desktop\6571-Assessment\qa-ai-practical-assessment\`  
**Node.js Location**: `C:\nodejs\node-v20.17.0-win-x64\`  
**Application Under Test**: https://practicesoftwaretesting.com  
**API Under Test**: https://api.practicesoftwaretesting.com  

---

## Assessment Completion Confirmation

✅ **This QA AI Practical Assessment is COMPLETE and ready for submission.**

- All 15 tests pass (7 API + 8 UI)
- All required deliverables present
- All technical requirements met
- All code created independently from scratch
- Full execution evidence available
- Comprehensive documentation provided

**Status**: READY FOR SUBMISSION ✅
