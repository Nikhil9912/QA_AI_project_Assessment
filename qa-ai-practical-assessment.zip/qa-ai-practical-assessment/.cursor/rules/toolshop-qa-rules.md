# Cursor Rules – Toolshop QA Assessment

## Project Context
- Application under test: Toolshop ecommerce (https://practicesoftwaretesting.com)
- REST API: https://api.practicesoftwaretesting.com
- Framework: Playwright + Prism Page Object Model (JavaScript / Node.js)
- Browser: Microsoft Edge only (channel: msedge) — Chromium is not used
- Config: playwright.toolshop.config.js (separate from any base framework config)

## Coding Standards
- Always use `data-test` attribute selectors — never CSS classes or XPath
- All page object methods must call `this.log.logger("message")` at least once
- Use `async/await` throughout — no `.then()` chains
- Export pattern for page objects: `module.exports = { ClassName }` (CJS)
- Import logger: `const loggerUtilities = require("../../../commonUtils/loggerUtil")`
- Always include `ignoreHTTPSErrors: true` in every `request.newContext()` call inside apiHelper.js
  (the project-level config option does NOT apply to standalone APIRequestContext)

## Test Design Rules
- Maximum 8 test cases per type (UI / API) — do not exceed
- Every test must be tagged with `@smoke` or `@regression` (or both) in the test title string
- Test IDs: TC-UI-XX for UI tests, TC-API-XX for API tests
- Smoke = critical path only; Regression = full coverage including negative paths
- workers: 1 always — API tests share state (bearerToken, cartId) via describe scope

## File Naming
- UI specs: `tests/UI Test/toolshop/NN_descriptiveName.spec.js`
- API specs: `tests/API Test/toolshop/NN_descriptiveName.spec.js`
- UI page objects: `UI/pageobjects/toolshop/pageName.js`
- API page objects: `API/pageobjects/toolshop/entityApiPage.js`

## Test Data Rules
- Dynamic emails: `nikhilqa_${Date.now()}@yopmail.com` (not @mailinator.com — blocked by the API)
- Dynamic passwords: `NikhQa#${Date.now().toString().slice(-5)}Zx!` (breach-safe pattern)
- Registration address field: always an array `["street value"]` — plain string returns 422
- Bearer token: obtained fresh in beforeAll via known stable credentials; stored to AccessToken.json

## What NOT to Do
- Do not use Chromium — Edge only
- Do not hardcode tokens, cart IDs, or invoice IDs
- Do not use `page.waitForTimeout()` as a primary wait strategy — use `waitFor({ state })` or `waitForURL`; waitForTimeout is only acceptable between the double-confirm clicks and after country select
- Do not run tests in parallel (workers must stay at 1 for API state sharing)
- Do not commit .env or API/testdata/*.json files
