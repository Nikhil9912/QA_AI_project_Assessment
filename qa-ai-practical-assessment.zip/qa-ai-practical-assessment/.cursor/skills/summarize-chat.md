# Skill: Summarize Chat to ai-prompts Format

## Purpose
After each focused Cursor/AI session, summarize the chat into the ai-prompts markdown format.
This keeps the prompt history clean and ensures evaluators can trace how AI was used.

## Usage
After completing a focused session (e.g. test design, debugging, data generation), run:
> Summarize this chat into ai-prompts format. For each prompt I sent, create an entry with:
> - Prompt: (the exact prompt or a faithful paraphrase)
> - AI Response Summary: (what the AI produced — 2–4 sentences)
> - Validation Notes / Debugging Outcome: (what I corrected, why, what the final result was)

## Output Format

```markdown
## Entry N – [Short Title]

**Prompt:**
> [Prompt text]

**AI Response Summary:**
[2–4 sentence summary of what the AI generated]

**Validation Notes / Debugging Outcome:**
- [What was correct and used as-is]
- [What was wrong and how you corrected it]
- [Final outcome]
```

## Why This Matters
- Assessment evaluates HOW AI was used — not just the final code
- Long chats get lost; a summarized .md is clean evidence for ai-prompts/
- Frees context window — start fresh chat for next phase without losing learnings
- Shows iterative prompting and careful review rather than blind copy-paste
