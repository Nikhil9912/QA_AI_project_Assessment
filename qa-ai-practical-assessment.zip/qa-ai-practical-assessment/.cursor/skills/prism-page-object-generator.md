# Skill: Prism Page Object Generator

## Purpose
Generate Playwright page object classes that follow the Toolshop Prism framework pattern exactly.

## Template

```javascript
const { expect } = require("@playwright/test");
require("dotenv").config();
const loggerUtilities = require("../../../commonUtils/loggerUtil");

class [PageName]Page {
  constructor(page) {
    this.page = page;
    this.log  = new loggerUtilities();

    // Locators — always use data-test attribute selectors
    this.elementName = page.locator("[data-test='data-test-value']");
  }

  async actionMethod(param) {
    await this.elementName.waitFor({ state: "visible", timeout: 15000 });
    await this.elementName.click();
    this.log.logger("Action description performed");
  }

  async verifyMethodName(expected) {
    await expect(this.elementName).toContainText(expected, { timeout: 10000 });
    this.log.logger(`Verified: ${expected}`);
  }
}

module.exports = { [PageName]Page };
```

## Key Conventions
- Constructor declares ALL locators as `this.xxx` properties — no inline locators in methods
- Every method has at least one `this.log.logger()` call
- Verification methods always use `expect()` with an explicit `timeout` option
- `waitFor({ state: "visible" })` before interactions — except on Angular stepper inactive steps
- For Angular stepper proceed buttons: check `toBeEnabled()` before clicking

## Usage Prompt Template

> I am using the Playwright Prism framework (CJS module.exports pattern).
> Here is an existing page object for reference: [paste an existing page object].
> Generate a new [PageName]Page for [URL / feature].
> The page has these elements: [list data-test attribute names and element types].
> Required methods: [list methods with brief descriptions].
> Browser: Microsoft Edge. Export pattern: `module.exports = { PageName }`.
> Note any Angular-specific waits that may be needed (steppers, reactive form validators).
