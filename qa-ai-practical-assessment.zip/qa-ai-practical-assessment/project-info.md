# Project Info — Toolshop QA Assessment

**Primary AI Tool(s) Used:** Kiro (AI development environment) / Cursor  
**Application Under Test:** PracticeSoftwareTesting Toolshop — https://practicesoftwaretesting.com  
**API Under Test:** https://api.practicesoftwaretesting.com  
**Assessment Start Date:** 2026-09-08  
**Submission Date:** 2026-09-08  

---

## Project Summary

This assessment tests the Toolshop ecommerce application — an Angular single-page application backed by a REST API — across two key flows: user registration & login (AC1) and an end-to-end purchase flow covering product search, cart management, 4-step checkout, and invoice verification (AC2). The automation suite is built using Playwright with a Page Object Model pattern on Microsoft Edge, covering 8 UI test cases and 7 API test cases categorised as Smoke and Regression.

---

## Tools Used

| Category | Tool |
|---|---|
| Browser | Microsoft Edge (msedge channel) |
| Automation Framework | Playwright v1.44+ |
| Language | JavaScript / Node.js |
| Page Object Pattern | Prism-style POM (constructor locators + logger injection) |
| API Testing | Playwright APIRequestContext (no Postman) |
| Logger | Winston via loggerUtil.js |
| AI Tool | Kiro / Cursor |
| Test Data | JSON fixture + dynamic Date.now() generation |
| State Persistence | StoreApiResponse (JSON files under API/testdata/) |
| Reporting | Playwright HTML Reporter → playwright-report-toolshop/ |

---

## Setup Summary

### 1. How I provide project and SUT context to the AI tool

Before generating any test cases or automation code, I provided the AI with the complete application context: the Angular SPA architecture, the REST API base URL, the specific `data-test` attribute naming convention the application uses, and the two acceptance criteria in full. I also described key behaviours confirmed through manual exploration — including that the Confirm button must be clicked twice to generate an invoice, and that `nav-menu` in the navbar is a `BUTTON` element (not an anchor), which is a common Angular pattern. For automation prompts, I always pasted an existing page object so the AI could match the exact constructor/logger/export pattern of the framework before generating new classes.

### 2. How I use AI for requirement analysis

I used AI to extract testable conditions from both acceptance criteria, producing a structured table of positive, negative, and edge cases with a risk level and recommended test layer for each. The AI's output was reviewed against the live application — it had assumed the checkout wizard had 3 steps when the actual app has 4, and had missed the empty-email negative case for login. I corrected both before finalising the test scope. AI also performed a gap analysis on the two ACs, surfacing 6 ambiguities (e.g. whether "address" in registration is a string or array) that I resolved by testing the live API directly.

### 3. How I use AI for test planning and strategy

I used AI to apply Smoke vs Regression classification to the full list of testable conditions. I provided explicit criteria: Smoke must be runnable in under 3 minutes and cover only critical-path tests (max 6); Regression covers full coverage including negative paths and edge cases (max 8). The AI's initial classification placed registration in Regression; I moved it to Smoke because it is a prerequisite for the purchase flow and needs early detection. The final classification (6 Smoke + 8 Regression across UI and API) respects the 5–8 per type constraint from the assessment brief.

### 4. How I use AI for manual test case design

I used AI to generate manual test cases in the FunctionalTestCase.csv format by providing the exact DOM selectors, expected error messages, and step-level behaviours I had confirmed through manual exploration. AI's initial outputs contained imprecise expected results (e.g. "error is shown" rather than the exact DOM text "Invalid email or password"). I corrected all expected results against the live application before including them in the CSV. The E2E checkout test case was expanded from AI's 14 steps to 16 steps after I confirmed the exact billing fields and the My Invoices verification step that AI had omitted.

### 5. How I use AI for automation design

I used AI to generate page object classes by providing an existing page object as a structural reference and listing the specific `data-test` attributes for each element. AI correctly followed the Prism pattern (constructor locators, logger injection, `waitFor` before interactions) but required two rounds of correction: the payment dropdown `waitFor` was placed too early (before Step 3 completed, so the element was hidden by the Angular stepper), and the `proceed-3` click was missing the `toBeEnabled()` guard. I also used AI to design the state-sharing pattern for API tests — a hybrid of in-memory describe-scoped variables and JSON file fallback.

### 6. How I validate and refine AI-generated test cases and scripts

Every AI-generated test case was reviewed against the live application before being committed. For UI tests, I ran the selector discovery script (generated by AI) against the live DOM to verify that element types matched (`button` vs `a`, `input[data-test='postal_code']` vs `input[data-test='postcode']`). For API tests, I validated each payload against the live API and iterated where the AI had made wrong assumptions (address field type, endpoint path, password policy). The rule I applied throughout: AI generates a first draft, I validate against the real system, then I correct and commit the validated version.

### 7. How I use AI for test data generation

I used AI to generate both static test data (registration payloads, billing address objects, boundary values for login) and dynamic patterns (timestamp-based unique email, breach-safe password). I provided the API contract requirements explicitly in the prompt — particularly the fact that `address` must be an array and the password must not be a commonly breached value. AI's first-pass data used `address` as a plain string (corrected to array after 422 from the API) and suggested `Test@12345!` as a password (rejected by the API as a known breached password). The final test data uses `Date.now()` for email and password generation, confirmed as uniqueness-safe across runs.

### 8. How I use AI for debugging failing tests

When TC-UI-06 failed at the payment dropdown step, I provided the exact Playwright error message, the relevant code block, and a description of the Angular stepper architecture to the AI. The AI correctly diagnosed the root cause (Angular stepper uses `display:none` on inactive steps — `waitFor({ state: "visible" })` correctly times out because the element is hidden, not absent). The fix — restructuring the checkout flow to complete the billing step before waiting for the payment dropdown — was provided by the AI and confirmed to work. For the API SSL certificate issue, the AI correctly identified that `ignoreHTTPSErrors` in the project config does not propagate to standalone `APIRequestContext` instances, and provided the fix of passing it directly to each `newContext()` call.

### 9. What information I avoid sharing with AI tools

I do not share any real production credentials, real customer data, or proprietary internal systems information with AI tools. For this assessment, even though the Toolshop test credentials (`customer@practicesoftwaretesting.com / welcome01`) are publicly documented as demo accounts, I followed the discipline of not pasting them directly into AI prompts — instead I referenced them as "known test account" or pasted only the structure, not the values. I also do not paste entire large codebases; I provide only the relevant file or function as context. This builds the habit of treating AI tools as collaborators that should receive the minimum necessary context to do the task.

### 10. How I would reuse this QA workflow in a real project

The workflow is reusable at three levels. At the prompt level: the requirement analysis prompt (conditions table + risk level), the Smoke/Regression classification prompt, and the page object generation prompt (with existing PO as context) are all templates that transfer directly to any Angular SPA project. At the pattern level: the selector discovery script, the `ignoreHTTPSErrors` fix in shared apiHelper, the hybrid state-sharing pattern (describe scope + JSON fallback), and the double-confirm timeout handling are patterns applicable to any Playwright project with API + UI state dependencies. At the process level: the four-phase workflow (requirements → test design → automation → evidence) with ai-prompts recorded at each phase creates an auditable trace of how AI contributed to the testing work.
