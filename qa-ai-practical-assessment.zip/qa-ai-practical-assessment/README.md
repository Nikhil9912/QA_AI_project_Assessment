# Toolshop QA Assessment

AI-assisted QA assessment covering UI and API testing of the [Toolshop ecommerce application](https://practicesoftwaretesting.com) using **Playwright** and the **Prism Page Object Model** pattern on **Microsoft Edge**.

---

## Repository Structure

```
qa-ai-practical-assessment/
├── FunctionalTestCase.csv              # Manual test suite — 15 cases (UI + API)
├── exploratory-testing-notes.md       # 45-minute exploratory session findings
├── project-info.md                    # AI workflow documentation (Part A)
├── README.md                          # This file
│
├── ai-prompts/                        # Full AI prompt history across all lifecycle phases
│   ├── requirements-and-planning.md   # Requirement extraction + risk analysis prompts
│   ├── test-design.md                 # Manual test case design prompts
│   ├── test-data.md                   # Test data generation prompts
│   ├── automation-and-debugging.md    # Page object generation + debug prompts
│   └── documentation-and-summary.md  # README + project-info generation prompts
│
├── execution-evidence/
│   └── README.md                      # Test results table + evidence file locations
│
├── .cursor/
│   ├── rules/
│   │   └── toolshop-qa-rules.md       # Cursor coding rules for this project
│   └── skills/
│       ├── prism-page-object-generator.md  # Reusable skill: generate Prism PO classes
│       └── summarize-chat.md              # Reusable skill: log AI sessions to ai-prompts/
│
└── prism_playwright/                  # Playwright automation project
    ├── package.json
    ├── playwright.toolshop.config.js  # Assessment config (Edge, 1 worker, 1 retry)
    ├── .env                           # Environment variables (BASE_URL, URL) — gitignored
    │
    ├── UI/
    │   ├── pageobjects/toolshop/      # Page object classes (Login, Register, Product, Checkout, Account)
    │   ├── resources/data/            # toolshopTestData.json — static test fixture
    │   └── utilities/                 # logger.js (Winston instance)
    │
    ├── API/
    │   ├── pageobjects/toolshop/      # API page objects (authApiPage, cartApiPage)
    │   ├── testdata/                  # Runtime JSON files (tokens, cartId, invoiceId) — gitignored
    │   └── utilities/                 # apiHelper.js, storeApiResponse.js
    │
    ├── commonUtils/
    │   └── loggerUtil.js              # Logger wrapper used by all page objects
    │
    └── tests/
        ├── UI Test/toolshop/          # 01_loginTest, 02_registrationTest, 03_e2ePurchaseFlow
        └── API Test/toolshop/         # 01_authApiTest, 02_cartAndInvoiceApiTest
```

---

## Prerequisites

- **Node.js** v18 or later
- **Microsoft Edge** browser installed (the test suite uses only the `msedge` channel — Chromium is not used)
- **npm** or **npx** available in PATH

---

## Setup

```bash
# 1. Navigate to the Playwright project
cd prism_playwright

# 2. Install dependencies
npm install

# 3. Install the Edge browser driver for Playwright
npx playwright install msedge

# 4. Verify the .env file exists with correct values
#    BASE_URL=https://practicesoftwaretesting.com
#    URL=https://api.practicesoftwaretesting.com
```

---

## Running Tests

All commands must be run from inside the `prism_playwright/` directory.

### Run all tests
```bash
npx playwright test --config=playwright.toolshop.config.js
```

### Run smoke tests only
```bash
npx playwright test --config=playwright.toolshop.config.js --grep @smoke
```

### Run regression tests only
```bash
npx playwright test --config=playwright.toolshop.config.js --grep @regression
```

### Run UI tests only
```bash
npx playwright test --config=playwright.toolshop.config.js --grep @ui
```

### Run API tests only
```bash
npx playwright test --config=playwright.toolshop.config.js --grep @api
```

### Run a specific spec file
```bash
npx playwright test "tests/UI Test/toolshop/01_loginTest.spec.js" --config=playwright.toolshop.config.js
npx playwright test "tests/API Test/toolshop/01_authApiTest.spec.js" --config=playwright.toolshop.config.js
```

---

## Test Report

The HTML report is generated automatically after each run.

### Open the report
```bash
# From inside prism_playwright/
npm run report
# or
npx playwright show-report playwright-report-toolshop
```

Report location: `prism_playwright/playwright-report-toolshop/index.html`

The report supports filtering by test name, status, and tag. Each test includes a screenshot, video recording, and step-level trace.

---

## Test Accounts

| Role | Email | Password |
|---|---|---|
| Customer (UI + API) | customer@practicesoftwaretesting.com | welcome01 |
| Admin (not used in automation) | admin@practicesoftwaretesting.com | welcome01 |
| New user (TC-UI-04 / TC-API-01) | Generated dynamically per run | Generated dynamically per run |

---

## Test Data

- **Static fixture:** `UI/resources/data/toolshopTestData.json` — valid user, invalid user, new user template, checkout billing, product search keyword
- **Dynamic data:** Registration email (`nikhilqa_${Date.now()}@yopmail.com`) and password (`NikhQa#${Date.now().slice(-5)}Zx!`) are generated at runtime to ensure uniqueness and avoid the API's breached-password rejection
- **API response files:** `API/testdata/` holds runtime JSON files (AccessToken, CartId, InvoiceId) written during test execution. These are gitignored but serve as in-session state fallback

---

## Notes

### Edge-only browser
This project uses only Microsoft Edge (`msedge` channel). Do not change the browser to Chromium — it is not configured in `playwright.toolshop.config.js`.

### Double-confirm behaviour
The Toolshop Confirm button must be clicked **twice** to generate an invoice. This is expected application behaviour. TC-UI-06 and `checkoutPage.confirmOrder()` implement this with a 2500ms pause between clicks to allow DOM re-render between transitions.

### workers: 1 requirement
API tests share state (`bearerToken`, `cartId`) via `test.describe` scope. Running with more than 1 worker causes race conditions and test failures. `workers: 1` is enforced in the config.

### retries: 1
One retry is configured to handle occasional Edge cold-start flakiness. A retry-pass is still a pass and is labelled as "retry" in the HTML report.

### Angular stepper selectors
The checkout wizard is an Angular Material stepper. Inactive steps have `display:none` — Playwright's `waitFor({ state: "visible" })` correctly times out on them. Methods are structured so that each step's elements are waited on only after the preceding step's proceed button has been clicked.
