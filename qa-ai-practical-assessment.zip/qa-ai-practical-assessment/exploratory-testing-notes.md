# Exploratory Testing Notes — Toolshop

**Tester:** Nikhil Sharma  
**Date:** 2026-09-08  
**Application:** https://practicesoftwaretesting.com  
**Session Duration:** 45 minutes  
**Focus Area:** Registration, Login, Checkout flow, Cart behaviour, Invoice generation

---

## Session Charter

> Explore the registration, login, checkout, and invoice generation flows to identify defects, edge cases, and usability issues not covered by the scripted test suite.

---

## Observations

### OBS-01: Cart state may reset on browser back-button during checkout

- **Description:** Using the browser Back button during checkout Step 2 (sign-in) and then navigating forward can cause the cart to display 0 items even though the session is active.
- **Steps:** Add product to cart → Navigate to checkout → Proceed to Step 2 → Click browser Back → Navigate forward
- **Actual:** Cart occasionally shows 0 items or reverts to Step 1 without items
- **Expected:** Cart state should be preserved across browser navigation within the same session
- **Severity:** Medium — impacts user experience and could cause lost orders; inconsistently reproducible
- **Recommended Action:** Manual regression — not automated (intermittent and requires complex session state setup)

---

### OBS-02: Quantity input accepts negative values client-side

- **Description:** The quantity input on the product detail page accepts `-1` as a value. The Add to Cart button remains enabled. When clicked, the server returns HTTP 400.
- **Steps:** Navigate to any product detail page → Change quantity to -1 → Click Add to Cart
- **Actual:** Button triggers; server returns 400 (server-side validation catches it)
- **Expected:** Client-side validation should prevent negative values from being submitted
- **Severity:** Low — server correctly rejects the value; this is a UX gap, not a data integrity issue
- **Recommended Action:** Log as a UX defect; do not automate within the current scope

---

### OBS-03: No loading indicator after Confirm during invoice generation

- **Description:** After clicking the Confirm button (for either the first or second time), there is a 2–3 second delay with no loading spinner or progress feedback. The page appears frozen.
- **Steps:** Complete checkout steps 1–4 → Click Confirm → Observe
- **Actual:** No visible feedback during invoice processing; the page is blank for 2–3 seconds
- **Expected:** A loading indicator should be displayed to prevent users from clicking Confirm additional times
- **Severity:** Medium — the lack of feedback could lead users to click a third time. If the API allows it, this could generate a duplicate invoice.
- **Recommended Action:** Raise as a UX + business risk defect; the `waitForTimeout(2500)` in `confirmOrder()` was added specifically to handle this gap in automation

---

### OBS-04: Search returns all products on single-character input

- **Description:** Entering a single character (e.g. "h") in the search bar and clicking Search returns all products, not a filtered subset.
- **Steps:** Navigate to home page → Enter "h" in the search bar → Click Search
- **Actual:** All products displayed (same result as an empty search)
- **Expected:** Either a minimum search length validation message, or a filtered result set matching the character
- **Severity:** Informational — this may be an intentional design choice (no minimum search length documented)
- **Recommended Action:** Monitor only; note for future exploratory sessions if a minimum search length is added

---

## Areas Tested

- [x] Login (valid, invalid, empty email)
- [x] Registration (valid, duplicate email, field validation)
- [x] Product browsing and search (keyword, single char, no results)
- [x] Add to cart (quantity 1, quantity 2, negative quantity)
- [x] Checkout flow (all 4 steps)
- [x] Cash on Delivery payment
- [x] Invoice generation (double confirm — both clicks required)
- [x] My Invoices list page
- [x] Logout flow

## Out of Scope (this session)

- Credit card / bank transfer payment flows
- Admin panel
- Password reset
- Mobile viewport testing
- API error injection (5xx responses)
