# AI Prompts – Test Data

---

## Entry 1 – User Registration Test Data with API Contract Awareness

**Prompt:**
> Generate test data for POST /users/register at https://api.practicesoftwaretesting.com/users/register.
>
> API contract requirements:
> - first_name, last_name: string
> - dob: YYYY-MM-DD format
> - address: ARRAY of strings (NOT a plain string)
> - postcode, city, state: string
> - country: 2-letter ISO 3166-1 alpha-2 code
> - phone: string
> - email: unique per registration; must not be a previously used address
> - password: min 8 chars, 1 uppercase, 1 number, 1 special char; must not be a commonly breached password
>
> Generate:
> 1. Valid registration payload — email unique via timestamp: nikhilqa_{TIMESTAMP}@yopmail.com
> 2. Duplicate email payload — use customer@practicesoftwaretesting.com (known existing account)
> 3. Missing mandatory field payload — omit phone field
>
> Password pattern for the valid payload: NikhQa#{TIMESTAMP_LAST_5}Zx!

**AI Response Summary:**
AI generated all 3 payloads correctly. Address correctly typed as an array. Timestamp placeholders used throughout. Password breach-avoidance rationale documented.

**Validation Notes:**
- Replaced `{TIMESTAMP}` placeholder with `Date.now()` in code — runtime-generated per test run
- Confirmed `@yopmail.com` domain is accepted — initial attempt with `@mailinator.com` was blocked (422 returned)
- Verified payload 1 against live API — returned 201 with correct user object structure
- Payload 3 (missing phone) returns 422 — documented for boundary reference, not automated within the 5–8 test limit

---

## Entry 2 – Invoice API Payload Construction

**Prompt:**
> I need to construct the POST /invoices payload for the Toolshop API. The assessment provides this example:
> { "billing_street": "Zoey Shore", "billing_city": "Hesselbury", ... "billing_country": "TG", "payment_method": "cash-on-delivery", "cart_id": "PLACEHOLDER", "payment_details": {} }
>
> Questions:
> 1. Is "TG" a valid ISO country code that the API will accept?
> 2. Is payment_details: {} correct for cash-on-delivery?
> 3. How do I share cartId between TC-API-05 and TC-API-07 in Playwright's test.describe scope?
> 4. Are there any other required fields beyond what is shown?

**AI Response Summary:**
AI answered all 4:
1. "TG" is Togo — valid ISO 3166-1 alpha-2, confirmed accepted by the API
2. `payment_details: {}` is the correct value for cash-on-delivery — no payment instrument needed
3. Recommended describe-scoped `let cartId` + JSON file fallback for isolated run support
4. No additional required fields — the example in the assessment doc is complete

**Validation Notes:**
- Implemented the hybrid pattern (describe-scoped variable + JSON file via StoreApiResponse) in 02_cartAndInvoiceApiTest.spec.js
- Used a UK address (billing_country: "GB") in my implementation — independently constructed, different from the TG example
- Confirmed GB country code accepted — invoice API returned 201 with valid invoice ID
- `payment_details: {}` confirmed via Swagger at /api/documentation

---

## Entry 3 – UI Checkout Billing Address Test Data

**Prompt:**
> The Toolshop checkout billing step (step 3 of 4) has these form fields:
> - country: SELECT data-test="country" — ISO 2-letter code
> - postal_code: INPUT text data-test="postal_code"
> - house_number: INPUT text data-test="house_number"
> - street: INPUT text data-test="street"
> - city: INPUT text data-test="city"
> - state: INPUT text data-test="state"
>
> The proceed-3 button is DISABLED until all fields have a value.
>
> Generate:
> 1. Complete valid billing address for E2E test
> 2. Set with missing city — to verify proceed-3 stays disabled (boundary)
> 3. Set with very long values (50+ chars) — to check input limits
>
> Format as a JavaScript object literal.

**AI Response Summary:**
AI generated all 3 data sets as JS object literals with correct data-test field names. Added a comment on which fields drive the proceed-3 enabled state.

**Validation Notes:**
- Data set 1 (country: "US", city: "Beverly Hills") used in TC-UI-06 — confirmed working on live app
- Data set 2 (missing city) tested manually — proceed-3 stays disabled as expected
- Data set 3 (50+ char values) tested manually — app accepts without truncation (client-side has no max-length enforced)
- Final test data stored in toolshopTestData.json checkout.billing section for consistency

---

## Entry 4 – Edge Case and Boundary Test Data for Login

**Prompt:**
> Generate boundary value and edge case test data for the Toolshop login form (email + password fields).
>
> Include:
> 1. Valid boundary: minimum valid email format, minimum valid password length
> 2. Invalid boundary: email missing @, email with no domain, password as spaces only
> 3. Security edge: SQL injection string in email, XSS payload in password
> 4. Special characters: unicode in password, emoji in email
> 5. Length extremes: 255-char email, 1-char password
>
> Format: Input Value | Field | Expected Behaviour | Test Layer
> Flag any that should NOT be automated and explain why.

**AI Response Summary:**
AI generated a 12-row table with expected behaviours. Correctly flagged SQL injection and XSS as manual-only due to WAF and security-context requirements. Noted Angular form validation handles most boundary cases client-side before API is hit.

**Validation Notes:**
- Empty string case automated as TC-UI-03
- SQL injection and XSS: documented in exploratory-testing-notes.md — not automated (outside the 5–8 test brief limit and requires security testing context)
- 255-char email: tested manually — API returns 422 on format validation
- Unicode password: tested manually — accepted by both UI and API
- These findings confirmed the scope decision to keep automation to the 8-test limit per type
