# AI Prompts – Documentation and Summary

---

## Entry 1 – README Generation

**Prompt:**
> Generate a README.md for a QA automation project with these specifications:
>
> Project: Toolshop QA Assessment
> App under test: https://practicesoftwaretesting.com (UI) and https://api.practicesoftwaretesting.com (API)
> Framework: Playwright + Prism pattern (JavaScript/Node.js)
> Browser: Microsoft Edge only (channel: msedge)
> Config file: playwright.toolshop.config.js
>
> Required sections:
> 1. Project overview (2–3 sentences)
> 2. Repository structure with one-line description per folder
> 3. Prerequisites (Node version, Edge requirement)
> 4. Setup commands (npm install + playwright install msedge)
> 5. Run commands — separate for: smoke only, regression only, UI only, API only, all tests
> 6. Report location and how to open it
> 7. Test accounts table
> 8. Notes: Edge-only constraint, double-confirm behaviour, workers=1 for API tests

**AI Response Summary:**
AI produced a clean README with all 8 sections. Commands correctly used `playwright.toolshop.config.js` throughout. Edge-only constraint clearly stated.

**Edits Made:**
- AI used `--project=toolshop_regression` in commands — corrected to `--config=playwright.toolshop.config.js --grep @regression` which matches how the config is actually invoked
- AI used the generic default report folder — corrected to `./playwright-report-toolshop/`
- Added `retries: 1` note — AI omitted it but it matters for CI users who see retry-pass results in the HTML report

**Reason for Edits:** AI does not have access to the actual config file, so framework-specific flags needed manual correction against the real configuration. Standard pattern: use AI for structure and prose, validate technical commands against the codebase.

---

## Entry 2 – project-info.md AI Workflow Documentation

**Prompt:**
> Write the project-info.md for a QA assessment. This document shows how I used AI throughout the testing lifecycle.
>
> Application context: Toolshop Angular SPA + REST API, tested with Playwright + Prism on Microsoft Edge.
>
> Actual experiences to base the responses on:
> - Used DOM inspection to discover real selectors (data-test attributes, but nav-menu is a BUTTON not ANCHOR)
> - Registration API returned 422 for address as string (must be array) and for breached passwords
> - Checkout has a 4-step Angular stepper where inactive steps are hidden in DOM
> - Ran selector discovery script to verify element types
> - Double-confirm is expected application behaviour
>
> Write 3–5 specific sentences per section for:
> 1–10. [All 10 sections from the project-info template]

**AI Response Summary:**
AI generated specific, experience-grounded responses for all 10 sections. Debugging section correctly referenced the Angular stepper issue and selector discovery workflow.

**Edits Made:**
- Section 6 (validation): Added specific API contract examples (address array, breached password 422) — AI had given a generic validation description
- Section 9 (what not to share): Replaced generic "don't share production credentials" with a nuanced answer about not sharing test-app credentials even though they are public, to build responsible habits
- Section 10 (reuse): AI focused on tool reuse — expanded to focus on workflow reuse (prompt templates, selector discovery pattern, hybrid state sharing)

**Reason for Edits:** Assessment evaluates whether AI outputs were reviewed and personalised. These edits demonstrate the validation loop and reflect actual project-specific experiences.

---

## Entry 3 – Exploratory Testing Session Summary

**Prompt:**
> I completed a 45-minute exploratory session on the Toolshop checkout and cart. Raw observations:
> 1. Browser back during checkout step 2 then forward causes cart to show 0 items inconsistently
> 2. Quantity input accepts -1 as a value; Add to Cart button remains enabled, but API returns 400
> 3. After clicking Confirm twice there is a 2–3 second blank period with no loading indicator — could lead to extra clicks
> 4. Single-character search returns all products — no minimum search length enforced
>
> For each: structured observation report with Title / Environment / Steps / Actual / Expected / Severity + justification / Suggested Fix / Recommendation.

**AI Response Summary:**
AI produced 4 structured observation reports with reasonable severity assignments and technically sound fix suggestions.

**Edits Made:**
- OBS-02 (negative quantity): AI assigned High severity — downgraded to Low after confirming server-side 400 catches it; risk is UX-only
- OBS-03 (no loading indicator): AI suggested "add a spinner" — I added the real business risk: users could click Confirm a third time creating duplicate invoice attempts
- OBS-04 (single character search): AI marked High — downgraded to Informational because returning all products on short queries is a valid design choice, not a defect

**Reason for Edits:** AI severity assignments lack business context. Applying domain knowledge when reviewing AI severity calls is a core QA responsibility.

---

## Entry 4 – AI Prompt Retrospective

**Prompt:**
> Review my AI-assisted QA workflow and give a retrospective:
>
> What I did well:
> - Provided full application context before asking for test cases
> - Iterated on prompts when API responses revealed wrong assumptions
> - Used a selector discovery script to validate AI-generated locators
> - Reviewed and corrected all AI outputs before committing
>
> What went wrong:
> - AI assumed checkout was 3 steps instead of 4
> - AI used wrong endpoint for cart add (first pass)
> - AI's waitFor visible pattern failed on Angular stepper hidden elements
>
> Provide: (1) assessment of effective prompt techniques, (2) 3 improvements for future projects, (3) reusable prompt template for Angular SPA page objects.

**AI Response Summary:**
AI identified context-specificity and iterative correction as the strongest techniques. Three improvements: (1) always include a DOM snippet or selector sample to prevent element type mismatches; (2) explicitly state the SPA framework so AI anticipates shadow DOM and stepper patterns; (3) add an "assumptions" section in prompts asking AI to state its assumptions before generating code.

**Edits Made:**
- None — this was a reflective prompt and the analytical response needed no domain correction
- The reusable Angular SPA prompt template from this entry is filed for future project use

**Reason for No Edits:** Meta-level analysis prompts do not require domain-specific correction; the AI's reflection on prompt quality was accurate and usable as-is.
