# AI Prompts – Test Design

---

## Entry 1 – Login Module Manual Test Cases

**Prompt:**
> I am designing manual test cases for the Toolshop login module (https://practicesoftwaretesting.com/auth/login).
>
> Application context:
> - Email input: input[data-test='email']
> - Password input: input[data-test='password']
> - Submit button: input[data-test='login-submit']
> - Error banner on failure: div.alert-danger[data-test='login-error'] with text "Invalid email or password"
> - On success: redirects to /account and shows button[data-test='nav-menu'] with user's full name
>
> Generate manual test cases in CSV format:
> Test ID, Type, Category, Title, Preconditions, Steps, Expected Result, Test Type
>
> Requirements:
> - Cover: valid credentials, invalid password, empty email
> - Precise expected results — use exact DOM text for errors
> - Classify each as Smoke or Regression
> - Test IDs: TC-UI-01, TC-UI-02, TC-UI-03
> - Maximum 3 test cases

**AI Response Summary:**
AI generated 3 well-structured test cases. Expected results used DOM-specific text. Smoke/Regression classification was accurate.

**Validation Notes:**
- AI's expected result for TC-UI-02 said "Incorrect password" — corrected to exact DOM text "Invalid email or password" after checking the live application
- TC-UI-03 (empty email): AI expected "required field validation popup" — live app allows submit click but stays on /login without redirecting. Corrected expected result to reflect actual behaviour
- All 3 cases added to FunctionalTestCase.csv unchanged after corrections

---

## Entry 2 – E2E Purchase Flow Test Case Design

**Prompt:**
> Design a step-by-step manual test case for the Toolshop 4-step checkout. Confirmed app behaviour:
>
> - Pre-condition: user logged in as customer@practicesoftwaretesting.com
> - Step 1 (Cart): Shows items and total. Button data-test="proceed-1"
> - Step 2 (Sign-in): Auto-passed when logged in. Button data-test="proceed-2"
> - Step 3 (Billing): Country / postal_code / house_number / street / city / state all mandatory. Button data-test="proceed-3" disabled until all fields are valid
> - Step 4 (Payment): Select payment-method dropdown. Confirm button data-test="finish" — must be clicked TWICE. First click queues order, second generates invoice.
>
> Format: Step Number | Action | Expected Result
> Add a section: "Risks to watch during execution"

**AI Response Summary:**
AI produced a 14-step test case with accurate step descriptions. Double-confirm modelled as two separate steps with distinct expected results (step 12: "order queued"; step 13: "invoice generated").

**Validation Notes:**
- Billing steps initially described generically as "fill billing details" — expanded to field-level steps based on actual data-test attributes
- AI's step 13 said "Payment Successful page appears" — live app shows inline success message on /checkout without page navigation. Corrected.
- Step 14 (navigate to My Invoices and verify) was missing — added after manual execution confirmed this is the final acceptance step
- Maps directly to TC-UI-06 in automation

---

## Entry 3 – API Test Scenario Design (Auth + Cart Flow)

**Prompt:**
> Design API test scenarios for the Toolshop REST API (base URL: https://api.practicesoftwaretesting.com) using Playwright APIRequestContext in JavaScript.
>
> AC1 (Auth):
> 1. POST /users/register — register new user
> 2. POST /users/login — get bearer token
> 3. POST /users/login with wrong credentials — verify 401
>
> AC2 (Cart + Invoice):
> 4. GET /products — retrieve product list
> 5. POST /carts — create empty cart
> 6. POST /carts/{cartId} — add product; GET /carts/{cartId} to verify
> 7. POST /invoices — generate invoice with billing + cart details
>
> For each scenario: Test ID | HTTP Method | Endpoint | Key Fields | Expected Status | Key Assertions | Test Type
>
> Constraints:
> - address in registration must be an array, not a string
> - Cart ID must be stored and reused across steps 5, 6, 7

**AI Response Summary:**
AI produced 7 scenarios with clear dependency chain and response-level assertions (not just status codes).

**Validation Notes:**
- AI used `POST /cart-items` for add-to-cart — corrected to `POST /carts/{cartId}` after checking Swagger docs at /api/documentation
- Address field type: AI used `"address": "string"` — corrected to `"address": ["string"]` after API returned 422 with message "The address field must be an array"
- AI's password suggestion (`Test@12345!`) rejected by API (breached password) — changed to timestamp-based pattern `NikhQa#${Date.now().slice(-5)}Zx!`
- These corrections are reflected in Entry 4 below

---

## Entry 4 – Iteration: Correcting API Scenarios After Live Validation

**Prompt:**
> The following API test scenarios need correction based on live testing:
>
> Issue 1: POST /users/register returned 422 — "The address field must be an array"
> Fix: Change address from string to array in request body.
>
> Issue 2: POST /users/register returned 422 — "The given password has appeared in a data leak"
> Fix: Use dynamic timestamp-based password that avoids known breach lists.
>
> Issue 3: Add-to-cart endpoint was wrong — correct is POST /carts/{cartId}
>
> Provide corrected payloads for each issue with explanation of the API contract reason.

**AI Response Summary:**
AI provided corrected payloads with clear explanations:
- Address as array: `"address": ["99 Automation Lane"]` — required per API OpenAPI schema
- Password: `NikhQa#${Date.now().toString().slice(-5)}Zx!` — unique per run, meets complexity, avoids breach list
- Cart endpoint: `POST /carts/{id}` is the RESTful pattern for adding a resource to a collection sub-resource

**Validation Notes:**
- Applied all three corrections to authApiPage.js and cartApiPage.js
- Re-ran TC-API-01 — confirmed 201 response
- Dynamic password confirmed unique per run — no false failures on re-execution
- This iteration demonstrates the value of AI-assisted testing needing validation loops, not one-shot generation

---

## Entry 5 – Logout Test Case Design

**Prompt:**
> Add a logout test case for the Toolshop app. Logout flow:
> 1. User is logged in — button[data-test='nav-menu'] shows user's name
> 2. Clicking nav-menu opens a dropdown with a[data-test='nav-sign-out']
> 3. Clicking nav-sign-out logs out and shows a[data-test='nav-sign-in']
>
> Design one manual test case (TC-UI-08) and the Playwright page object methods async logout() and async verifyLogoutSuccess().
> Classify as Smoke.

**AI Response Summary:**
AI produced the test case and both methods. Correctly identified nav-menu as a BUTTON element (not an anchor).

**Validation Notes:**
- Verified element types via live DOM inspection — `button[data-test='nav-menu']` confirmed
- `a[data-test='nav-sign-out']` confirmed as an anchor inside the dropdown
- Added TC-UI-08 to FunctionalTestCase.csv as Smoke
- Test passes consistently without flakiness
