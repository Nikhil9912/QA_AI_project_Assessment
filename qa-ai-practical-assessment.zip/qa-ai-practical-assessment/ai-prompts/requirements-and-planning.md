# AI Prompts – Requirements and Planning

---

## Entry 1 – SUT Context and Requirement Extraction

**Prompt:**
> You are a senior QA engineer. The application under test is Toolshop — an Angular single-page ecommerce app at https://practicesoftwaretesting.com, backed by a REST API at https://api.practicesoftwaretesting.com.
>
> Two acceptance criteria exist:
>
> AC1 — User Registration & Login: The user should be able to register with valid details, log in using registered credentials, and verify their profile information.
>
> AC2 — End-to-End Purchase Flow: The user should be able to browse products, add items to the cart, complete checkout using Cash on Delivery, and view the generated invoice under My Invoices. Note: the Confirm button must be clicked twice to generate the invoice.
>
> Tasks:
> 1. Extract all testable conditions from AC1 and AC2 — positive, negative, and edge cases.
> 2. Identify boundary values for each condition.
> 3. Flag integration risks between UI and API.
> 4. Distinguish which conditions are suited to UI automation vs API automation vs manual exploratory testing.
> Format output as a table: Condition | Type | Layer | Risk Level (High/Medium/Low).

**AI Response Summary:**
AI produced a 17-row conditions table. Key outputs:
- Duplicate email registration flagged as High risk (data integrity)
- Double-confirm pattern flagged as potential race condition on slow networks / CI runners
- API token expiry mid-flow flagged as Medium risk
- Recommended manual-only coverage for browser back-button state loss and payment gateway timeouts

**My Validation Notes:**
- Manually explored the live app before accepting the table
- AI initially assumed checkout has 3 steps — corrected to 4 (Cart → Sign-in → Billing → Payment)
- Removed 3 out-of-scope conditions (admin panel, password reset, social login)
- Added TC for empty email on login — AI omitted it from the negative list
- Final scoped set: 8 UI cases + 7 API cases

---

## Entry 2 – Smoke vs Regression Classification

**Prompt:**
> Given these 15 testable conditions for the Toolshop app [pasted conditions table], apply smoke vs regression classification using:
>
> Smoke: validates app is alive and critical paths unbroken; max 6 tests; must complete in under 3 minutes.
> Regression: full functional coverage including negative paths and edge cases; max 8 tests.
>
> For each test: Test ID | Classification | One-sentence justification.
> Flag any test estimated over 60 seconds for smoke — suggest what to stub.

**AI Response Summary:**
AI classified 5 tests as Smoke and 9 as Regression. Correctly identified E2E purchase flow as the highest-value critical path for Smoke despite its length. Suggested mocking email uniqueness in registration smoke — not adopted as it would change test intent.

**My Validation Notes:**
- TC-UI-04 (registration) initially classified as Regression — moved to Smoke because registration is a prerequisite for the purchase flow; early detection matters
- TC-UI-08 (logout) moved to Smoke — it is a critical security function
- Final counts: 6 Smoke, 8 Regression across UI + API, within the 5–8 per type constraint

---

## Entry 3 – Risk Analysis for Checkout Flow

**Prompt:**
> Perform a QA risk analysis for the Toolshop 4-step checkout (1: Cart, 2: Sign-in, 3: Billing, 4: Payment).
>
> Known behaviours:
> - Confirm button must be clicked twice to generate an invoice
> - Billing fields are mandatory and not pre-filled from the user profile
> - Payment method dropdown renders only after Step 3 completes (Angular stepper hides inactive step content)
>
> For each step: top 2 failure modes | probability | recommended test approach.
> Also identify cross-step state dependencies that could cause test flakiness.

**AI Response Summary:**
AI produced a per-step risk matrix. Key findings:
- Step 3 (Billing) identified as highest risk — mandatory fields with disabled proceed button until all validators pass
- Double-confirm flagged as a potential timing issue on slow CI runners due to DOM re-render between clicks
- Cart state loss on back-navigation flagged as a cross-step Medium risk

**My Validation Notes:**
- Confirmed Step 3 risk by inspecting the DOM — proceed-3 button has `disabled` attribute until Angular validators pass
- Implemented `waitForTimeout(2500)` between the two confirm clicks based on this analysis
- Cart state risk confirmed via exploratory testing (see exploratory-testing-notes.md)
- Cross-step state risk mitigated by `workers: 1` in playwright.toolshop.config.js

---

## Entry 4 – Acceptance Criteria Gap Analysis

**Prompt:**
> Review these two ACs for the Toolshop assessment and identify ambiguities or implicit behaviours a QA engineer must clarify:
>
> AC1: "register with valid details, log in, verify profile information"
> AC2: "browse products, add multiple items, checkout with Cash on Delivery, view generated invoice"
>
> For each ambiguity: Ambiguity | Assumed Behaviour | Clarification Question.

**AI Response Summary:**
AI identified 6 ambiguities including: what "valid details" means for registration (no password policy stated), whether "multiple items" means multiple products or multiple quantities of one product, and what "successfully view" means for the invoice (list view vs detail view).

**My Validation Notes:**
- Resolved all 6 ambiguities by testing the live app directly
- "Valid details" — confirmed via API: address must be an array, password cannot be a known breached value
- "Multiple items" — interpreted as quantity ≥ 2 of a single product for simplicity within the 5–8 test limit
- "Successfully view" — confirmed as invoice row appearing in the My Invoices list page
- Resolved ambiguities directly shaped the test data used in automation
