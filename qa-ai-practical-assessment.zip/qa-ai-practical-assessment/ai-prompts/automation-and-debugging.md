# AI Prompts – Automation and Debugging

---

## Entry 1 – Page Object Generation Following Prism Framework Pattern

**Prompt:**
> I am building a Playwright automation suite using the Prism framework (JavaScript/Node.js Page Object Model). Here is an existing page object for reference: [pasted loginPage.js constructor and method structure].
>
> Generate a CheckoutPage class for the Toolshop 4-step Angular checkout wizard.
> Step details:
> - Step 1: Cart review. data-test="proceed-1"
> - Step 2: Sign-in. data-test="proceed-2" (auto-passed when logged in)
> - Step 3: Billing form. data-test selectors: country (select), postal_code, house_number, street, city, state (inputs). data-test="proceed-3" DISABLED until all fields are valid
> - Step 4: Payment. data-test="payment-method" select + data-test="finish" button — must be clicked TWICE
>
> Requirements:
> - Match the constructor/logger/locator pattern exactly
> - Use data-test selectors exclusively
> - Include a logger call in each method
> - confirmOrder() must click twice with a waitForTimeout between clicks

**AI Response Summary:**
AI generated a complete CheckoutPage class following the Prism pattern. data-test selectors throughout. Logger calls in all methods. confirmOrder() implemented with two clicks and a 2500ms pause.

**Debugging Outcome:**
- Initial generation called `waitFor({ state: "visible" })` on the payment dropdown — failed because the dropdown only renders after Step 3 is activated (Angular stepper hides inactive steps)
- Fix: payment dropdown wait moved inside `selectPaymentMethod()` and called only after `fillBillingAndProceed()` completes
- Learning: Angular stepper uses `display:none` on inactive steps — elements exist in DOM but `offsetParent === null`. Playwright's visibility check correctly rejects these.

---

## Entry 2 – Debugging: Angular Stepper Hidden Elements

**Prompt:**
> My Playwright test fails on:
> `await this.paymentSelect.waitFor({ state: "visible", timeout: 10000 });`
> Error: `locator.waitFor: Timeout 10000ms exceeded. locator resolved to hidden <select data-test="payment-method">`
>
> The element is in the DOM but offsetParent is null. I am on checkout Step 3 — payment dropdown is part of Step 4 which hasn't been activated yet.
>
> Current flow: proceedFromCart() ✅ → proceedFromSignIn() ✅ → selectPaymentMethod() ❌
> I am skipping the billing form fill + proceed-3 click.
>
> 1. Explain why Angular stepper elements resolve as hidden even when in the DOM.
> 2. Refactor my checkout flow to add the missing billing step.
> 3. Handle the proceed-3 disabled state — it won't be clickable until all fields are valid.

**AI Response Summary:**
AI explained Angular Material stepper uses `[hidden]` attribute and `display:none` on inactive steps — Playwright's `waitFor({ state: "visible" })` correctly rejects these. Provided a `fillBillingAndProceed()` method filling all required fields before clicking proceed-3. Added `expect(proceed3).toBeEnabled()` assertion to confirm the button is interactive before clicking.

**Debugging Outcome:**
- Applied the refactored method — TC-UI-06 passed on next run after the fix
- `toBeEnabled()` assertion caught a case where the country select wasn't yet hydrated by Angular — added `waitForTimeout(900)` after country selection to allow form validators to update
- Documented: Angular reactive forms disable submit buttons until all validators pass — always check `toBeEnabled()` before clicking Angular stepper proceed buttons

---

## Entry 3 – Debugging: API ignoreHTTPSErrors on Standalone APIRequestContext

**Prompt:**
> My Playwright API tests fail with: `Error: self-signed certificate in certificate chain`
> when calling https://api.practicesoftwaretesting.com.
>
> My playwright.toolshop.config.js has `ignoreHTTPSErrors: true` under the project `use` block.
> The API tests use `request.newContext()` inside apiHelper.js — independent of the browser config.
>
> Does `ignoreHTTPSErrors` in the project config apply to `request.newContext()` calls?
> If not, how do I pass it?

**AI Response Summary:**
AI confirmed that `ignoreHTTPSErrors` in the project config applies only to browser page requests, NOT to standalone `APIRequestContext` created via `request.newContext()`. To fix: pass `ignoreHTTPSErrors: true` explicitly in every `newContext()` call inside apiHelper.js.

**Debugging Outcome:**
- Added `ignoreHTTPSErrors: true` to all 4 `request.newContext()` calls in apiHelper.js (getResponse, postResponse, putResponse, deleteResponse)
- All 7 API tests passed after this fix
- Team note: any shared apiHelper.js must explicitly include this option — project-level config does not propagate to standalone API contexts

---

## Entry 4 – State Sharing Pattern for Sequential API Tests

**Prompt:**
> In my Playwright API test.describe block I have this dependency chain:
> - TC-API-05: Creates cart → must store cartId
> - TC-API-06: Adds product using cartId and productId from TC-API-04
> - TC-API-07: Generates invoice using cartId
>
> workers: 1. Two constraints:
> 1. Tests should be independently re-runnable for debugging
> 2. cartId must survive across test boundaries
>
> Evaluate:
> Option A: describe-scoped `let cartId` (in-memory, fast, lost between runs)
> Option B: Write to JSON file, read at start of dependent test (persistent, slower)
> Option C: Use test.info().annotations (read-only metadata, cannot pass data)
>
> Recommend the best balance of reliability, debuggability, and CI compatibility.

**AI Response Summary:**
AI recommended hybrid of Option A + B: use `let cartId` for within-run performance, write to JSON file as fallback for isolated debugging. Explained Option C is read-only and cannot pass data between tests.

**Debugging Outcome:**
- Implemented hybrid: in-memory `let cartId` + `store.saveToFile({ cartId }, "CartId")` + file-read fallback at the start of TC-API-06 and TC-API-07
- Tested isolated TC-API-07 run — correctly reads CartId.json from previous run
- Pattern applied consistently for cartId, productId, invoiceId across the suite

---

## Entry 5 – Selector Discovery for Angular SPA

**Prompt:**
> I need to verify the correct Playwright selectors for the Toolshop Angular app. Rather than reading pages by hand, write a Node.js Playwright script that:
> 1. Logs in with known credentials
> 2. Navigates to a given page URL (passed as argument)
> 3. Dumps all elements with data-test attributes — tag name, data-test value, text content, visibility (offsetParent check)
> 4. For interactive elements also captures disabled state
>
> Browser: Microsoft Edge (msedge channel)

**AI Response Summary:**
AI generated a reusable `debug_selectors.js` script. Running it revealed that `nav-menu` is a BUTTON element (not an ANCHOR as initially assumed), and that address split into `house_number` + `street` inputs (not a single address field on the registration form).

**Debugging Outcome:**
- Script corrected 3 selector assumptions:
  - `a[data-test='nav-menu']` → `button[data-test='nav-menu']`
  - `input[data-test='postcode']` → `input[data-test='postal_code']`
  - `input[data-test='address']` → `house_number` + `street` separate inputs
- Script deleted after selector discovery — not committed as it is a debugging aid only
