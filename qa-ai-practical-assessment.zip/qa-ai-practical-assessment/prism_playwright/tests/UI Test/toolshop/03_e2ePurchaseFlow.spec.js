const { test, expect } = require("@playwright/test");
const { POManagerToolshop } = require("../../../UI/pageobjects/toolshop/POManagerToolshop");
const testData = require("../../../UI/resources/data/toolshopTestData.json");

/**
 * UI Test Suite — E2E Purchase Flow
 * Covers: TC-UI-06, TC-UI-07
 *
 * TC-UI-06 is the critical end-to-end path:
 *   Login → Search Product → Add to Cart → 4-step Checkout → Confirm (×2) → Verify Invoice
 *
 * The double-confirm behaviour is expected: first click queues the order,
 * second click generates the invoice. A 2500ms pause is inserted between
 * them to allow the Angular DOM to update between transitions.
 */
test.describe("Toolshop UI — E2E Purchase Flow", () => {
  let pom;

  test.beforeEach(async ({ page }) => {
    pom = new POManagerToolshop(page);
    const loginPage = pom.getLoginPage();
    await loginPage.goto();
    await loginPage.navigateToLogin();
    await loginPage.login(testData.validUser.email, testData.validUser.password);
    await loginPage.verifyLoginSuccess();
  });

  /**
   * TC-UI-06: Full E2E purchase flow — search, cart, 4-step checkout, invoice verification.
   * @smoke @regression @ui
   */
  test("TC-UI-06: E2E — search product, checkout with Cash on Delivery, verify invoice @smoke @regression @ui", async ({ page }) => {
    const productPage  = pom.getProductPage();
    const checkoutPage = pom.getCheckoutPage();
    const accountPage  = pom.getAccountPage();
    const billing      = testData.checkout.billing;

    // Search and add product to cart
    await productPage.goto();
    await productPage.searchProduct(testData.products.searchKeyword);
    await productPage.clickFirstProduct();
    await productPage.setQuantity(1);
    await productPage.addToCart();
    await productPage.verifyCartBadgeVisible();

    // Navigate to cart
    await productPage.goToCart();
    await checkoutPage.verifyCartNotEmpty();

    // 4-step checkout wizard
    await checkoutPage.proceedFromCart();          // Step 1: Cart review
    await checkoutPage.proceedFromSignIn();        // Step 2: Sign-in (auto-passed)
    await checkoutPage.fillBillingAndProceed({     // Step 3: Billing address
      country:     billing.country,
      postcode:    billing.postcode,
      houseNumber: billing.houseNumber,
      street:      billing.street,
      city:        billing.city,
      state:       billing.state,
    });
    await checkoutPage.selectPaymentMethod(testData.checkout.paymentMethod); // Step 4: Payment
    await checkoutPage.confirmOrder();             // Confirm ×2

    await checkoutPage.verifyOrderSuccess();

    // Verify invoice appears in My Invoices
    await accountPage.goToMyInvoices();
    await accountPage.verifyInvoicePresent();

    console.log("TC-UI-06 PASSED: E2E purchase flow and invoice verified");
  });

  /**
   * TC-UI-07: Add product to cart and verify cart reflects the item and total.
   * @regression @ui
   */
  test("TC-UI-07: Verify cart displays product and total after add-to-cart @regression @ui", async ({ page }) => {
    const productPage  = pom.getProductPage();
    const checkoutPage = pom.getCheckoutPage();

    await productPage.goto();
    await productPage.clickFirstProduct();
    await productPage.setQuantity(2);
    await productPage.addToCart();
    await productPage.verifyCartBadgeVisible();
    await productPage.goToCart();
    await checkoutPage.verifyCartNotEmpty();
    console.log("TC-UI-07 PASSED: Cart displayed correct item and total after add");
  });
});
