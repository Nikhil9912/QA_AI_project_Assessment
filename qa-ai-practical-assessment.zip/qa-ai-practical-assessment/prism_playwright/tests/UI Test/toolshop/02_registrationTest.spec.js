const { test, expect } = require("@playwright/test");
const { POManagerToolshop } = require("../../../UI/pageobjects/toolshop/POManagerToolshop");
const testData = require("../../../UI/resources/data/toolshopTestData.json");

/**
 * UI Test Suite — User Registration
 * Covers: TC-UI-04, TC-UI-05
 *
 * Dynamic email generation ensures TC-UI-04 creates a unique account every run.
 * TC-UI-05 deliberately uses a pre-existing email to verify duplicate-account protection.
 */
test.describe("Toolshop UI — Registration Tests", () => {
  let pom;

  test.beforeEach(async ({ page }) => {
    pom = new POManagerToolshop(page);
    await pom.getRegisterPage().navigateToRegister();
  });

  /**
   * TC-UI-04: New user registration with all valid fields.
   * Dynamic email appended with timestamp ensures uniqueness per run.
   * @smoke @regression @ui
   */
  test("TC-UI-04: Verify new user registration with valid details @smoke @regression @ui", async ({ page }) => {
    const registerPage = pom.getRegisterPage();
    const uniqueEmail  = `nikhilqa_${Date.now()}@yopmail.com`;

    const userData = {
      ...testData.newUser,
      email: uniqueEmail,
      password: `NikhQa#${Date.now().toString().slice(-5)}Zx!`,  // breach-safe dynamic password
    };

    await registerPage.fillRegistrationForm(userData);
    await registerPage.submitRegistration();
    await registerPage.verifyRegistrationSuccess();
    console.log(`TC-UI-04 PASSED: New user registered — ${uniqueEmail}`);
  });

  /**
   * TC-UI-05: Registration blocked for an already-registered email.
   * Uses the known test account to trigger a duplicate-email API error.
   * @regression @ui
   */
  test("TC-UI-05: Verify registration fails for duplicate email @regression @ui", async ({ page }) => {
    const registerPage = pom.getRegisterPage();
    const duplicateData = { ...testData.newUser, email: testData.validUser.email };

    await registerPage.fillRegistrationForm(duplicateData);
    await registerPage.submitRegistration();
    await registerPage.verifyRegistrationError();
    console.log("TC-UI-05 PASSED: Duplicate email registration error confirmed");
  });
});
