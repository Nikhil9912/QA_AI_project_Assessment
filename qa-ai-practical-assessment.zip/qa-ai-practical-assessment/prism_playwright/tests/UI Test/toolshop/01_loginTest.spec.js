const { test, expect } = require("@playwright/test");
const { POManagerToolshop } = require("../../../UI/pageobjects/toolshop/POManagerToolshop");
const testData = require("../../../UI/resources/data/toolshopTestData.json");

/**
 * UI Test Suite — Login & Logout
 * Covers: TC-UI-01, TC-UI-02, TC-UI-03, TC-UI-08
 */
test.describe("Toolshop UI — Login & Logout Tests", () => {
  let pom;

  test.beforeEach(async ({ page }) => {
    pom = new POManagerToolshop(page);
    await pom.getLoginPage().goto();
    await pom.getLoginPage().navigateToLogin();
  });

  /**
   * TC-UI-01: Valid credentials — user should land on account page.
   * @smoke @regression @ui
   */
  test("TC-UI-01: Verify login succeeds with valid credentials @smoke @regression @ui", async ({ page }) => {
    const loginPage = pom.getLoginPage();
    await loginPage.login(testData.validUser.email, testData.validUser.password);
    await loginPage.verifyLoginSuccess();
    console.log("TC-UI-01 PASSED: Valid credentials login confirmed");
  });

  /**
   * TC-UI-02: Invalid credentials — error message should appear.
   * @regression @ui
   */
  test("TC-UI-02: Verify error displayed for invalid credentials @regression @ui", async ({ page }) => {
    const loginPage = pom.getLoginPage();
    await loginPage.login(testData.invalidUser.email, testData.invalidUser.password);
    await loginPage.verifyLoginError("Invalid email or password");
    console.log("TC-UI-02 PASSED: Invalid credentials error banner confirmed");
  });

  /**
   * TC-UI-03: Empty email field — form should not redirect away from login.
   * @regression @ui
   */
  test("TC-UI-03: Verify login is blocked when email field is empty @regression @ui", async ({ page }) => {
    const loginPage = pom.getLoginPage();
    await loginPage.login("", testData.validUser.password);
    await expect(page).toHaveURL(/login/, { timeout: 5000 });
    console.log("TC-UI-03 PASSED: Empty email prevented navigation away from login");
  });

  /**
   * TC-UI-08: Logout flow — sign-in link should be restored after logout.
   * @smoke @regression @ui
   */
  test("TC-UI-08: Verify user can logout and sign-in link is restored @smoke @regression @ui", async ({ page }) => {
    const loginPage = pom.getLoginPage();
    await loginPage.login(testData.validUser.email, testData.validUser.password);
    await loginPage.verifyLoginSuccess();
    await loginPage.logout();
    await loginPage.verifyLogoutSuccess();
    console.log("TC-UI-08 PASSED: Logout confirmed — sign-in link visible in navbar");
  });
});
