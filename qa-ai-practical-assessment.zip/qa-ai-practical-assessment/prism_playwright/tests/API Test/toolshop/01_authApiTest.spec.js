const { test, expect } = require("@playwright/test");
const { ApiHelper }       = require("../../../API/utilities/apiHelper");
const { StoreApiResponse } = require("../../../API/utilities/storeApiResponse");
const authApiPage         = require("../../../API/pageobjects/toolshop/authApiPage");

/**
 * API Test Suite — Authentication
 * Covers: TC-API-01, TC-API-02, TC-API-03
 *
 * AC1: A new user registers via API, logs in to obtain a bearer token,
 *      and invalid credentials are rejected with HTTP 401.
 *
 * Key constraints (discovered via live API validation):
 *  - address field must be an ARRAY — plain string returns 422
 *  - password must not be a commonly breached value — API returns 422 otherwise
 *  - email domain @mailinator.com is blocked — use @yopmail.com
 *  - Dynamic timestamp suffix makes email unique per run and password breach-safe
 */
test.describe("Toolshop API — Authentication (AC1)", () => {
  let api;
  let store;

  // Unique per run — prevents duplicate-email 422 on re-runs
  const testEmail    = `nikhilqa_${Date.now()}@yopmail.com`;
  const testPassword = `NikhQa#${Date.now().toString().slice(-5)}Zx!`;

  test.beforeAll(async () => {
    api   = new ApiHelper();
    store = new StoreApiResponse();
  });

  /**
   * TC-API-01: Register a brand-new user via POST /users/register.
   * Expects 201 with the user id and email echoed back.
   * @smoke @regression @api
   */
  test("TC-API-01: Register new user via API @smoke @regression @api", async () => {
    const payload  = authApiPage.buildRegisterPayload(testEmail, testPassword);
    const response = await api.postResponse(
      authApiPage.registerEndpoint,
      payload,
      authApiPage.baseHeaders
    );

    expect(response.status()).toBe(201);
    const body = await response.json();
    expect(body).toHaveProperty("id");
    expect(body.email).toBe(testEmail);

    // Persist credentials for downstream tests
    store.saveToFile({ registeredEmail: testEmail, registeredPassword: testPassword }, "RegisteredUser");
    console.log(`TC-API-01 PASSED: User registered — ${testEmail}`);
  });

  /**
   * TC-API-02: Login with the registered credentials to obtain a bearer token.
   * Uses known stable account for deterministic token retrieval.
   * @smoke @regression @api
   */
  test("TC-API-02: Login and obtain bearer token @smoke @regression @api", async () => {
    const payload = authApiPage.buildLoginPayload(
      "customer@practicesoftwaretesting.com",
      "welcome01"
    );
    const response = await api.postResponse(
      authApiPage.loginEndpoint,
      payload,
      authApiPage.baseHeaders
    );

    expect(response.status()).toBe(200);
    const body = await response.json();
    expect(body).toHaveProperty("access_token");
    expect(body.access_token.length).toBeGreaterThan(0);

    store.saveToFile({ access_token: body.access_token }, "AccessToken");
    console.log("TC-API-02 PASSED: Bearer token obtained and stored");
  });

  /**
   * TC-API-03: Login with wrong credentials must return HTTP 401.
   * @regression @api
   */
  test("TC-API-03: Login with invalid credentials returns 401 @regression @api", async () => {
    const payload = authApiPage.buildLoginPayload("wrong@email.com", "WrongPass999!");
    const response = await api.postResponse(
      authApiPage.loginEndpoint,
      payload,
      authApiPage.baseHeaders
    );

    expect(response.status()).toBe(401);
    console.log("TC-API-03 PASSED: Invalid credentials correctly returned 401");
  });
});
