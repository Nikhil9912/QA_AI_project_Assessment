const { test, expect } = require("@playwright/test");
const { ApiHelper }        = require("../../../API/utilities/apiHelper");
const { StoreApiResponse } = require("../../../API/utilities/storeApiResponse");
const authApiPage          = require("../../../API/pageobjects/toolshop/authApiPage");
const cartApiPage          = require("../../../API/pageobjects/toolshop/cartApiPage");

/**
 * API Test Suite — Cart & Invoice Flow
 * Covers: TC-API-04, TC-API-05, TC-API-06, TC-API-07
 *
 * AC2: Authenticated user retrieves products, creates a cart,
 *      adds a product, and generates an invoice.
 *
 * State sharing pattern:
 *  - describe-scoped `let` variables for within-run performance
 *  - JSON file fallback (StoreApiResponse) for isolated test re-runs
 *
 * workers: 1 is required — tests share bearerToken, cartId, productId
 * via describe scope and cannot safely run in parallel.
 */
test.describe("Toolshop API — Cart & Invoice Flow (AC2)", () => {
  let api;
  let store;
  let bearerToken;
  let cartId;
  let productId;

  test.beforeAll(async () => {
    api   = new ApiHelper();
    store = new StoreApiResponse();

    // Obtain a fresh token once for the entire suite
    const loginPayload = authApiPage.buildLoginPayload(
      "customer@practicesoftwaretesting.com",
      "welcome01"
    );
    const loginRes = await api.postResponse(
      authApiPage.loginEndpoint,
      loginPayload,
      authApiPage.baseHeaders
    );
    const loginBody = await loginRes.json();
    bearerToken = loginBody.access_token;
    console.log("beforeAll: Bearer token refreshed for cart+invoice suite");
  });

  /**
   * TC-API-04: Retrieve the product catalogue (GET /products).
   * Captures the first product ID for use in TC-API-06 (add to cart).
   * @smoke @regression @api
   */
  test("TC-API-04: Retrieve product list via API @smoke @regression @api", async () => {
    const headers  = cartApiPage.buildAuthHeaders(bearerToken);
    const response = await api.getResponse(cartApiPage.productsEndpoint, headers);

    expect(response.status()).toBe(200);
    const body = await response.json();
    expect(body).toHaveProperty("data");
    expect(body.data.length).toBeGreaterThan(0);

    productId = body.data[0].id;
    console.log(`TC-API-04 PASSED: ${body.data.length} products retrieved. Using productId: ${productId}`);
  });

  /**
   * TC-API-05: Create a new empty cart (POST /carts).
   * Cart ID is stored for TC-API-06 and TC-API-07.
   * @smoke @regression @api
   */
  test("TC-API-05: Create new cart via API @smoke @regression @api", async () => {
    const headers  = cartApiPage.buildAuthHeaders(bearerToken);
    const response = await api.postResponse(
      cartApiPage.cartsEndpoint,
      cartApiPage.buildCreateCartPayload(),
      headers
    );

    expect(response.status()).toBe(201);
    const body = await response.json();
    expect(body).toHaveProperty("id");
    cartId = body.id;

    store.saveToFile({ cartId }, "CartId");
    console.log(`TC-API-05 PASSED: Cart created — cartId: ${cartId}`);
  });

  /**
   * TC-API-06: Add the product from TC-API-04 to the cart and verify it appears.
   * Falls back to CartId.json if cartId not in describe scope (isolated run).
   * @regression @api
   */
  test("TC-API-06: Add product to cart and verify cart contents @regression @api", async () => {
    // Fallback: read from file if running this test in isolation
    if (!cartId) {
      const saved = store.readFromFile("CartId");
      cartId = saved?.cartId;
    }
    expect(cartId).toBeTruthy();

    const headers     = cartApiPage.buildAuthHeaders(bearerToken);
    const addPayload  = cartApiPage.buildAddToCartPayload(
      productId || "01jnfp89x0gcxzs4c21tga10k8",
      1
    );

    const addResponse = await api.postResponse(
      `${cartApiPage.cartsEndpoint}/${cartId}`,
      addPayload,
      headers
    );
    expect([200, 201]).toContain(addResponse.status());

    // Verify cart now contains the added product
    const cartResponse = await api.getResponse(
      `${cartApiPage.cartsEndpoint}/${cartId}`,
      headers
    );
    expect(cartResponse.status()).toBe(200);
    const cartBody = await cartResponse.json();
    expect(cartBody.cart_items.length).toBeGreaterThan(0);

    console.log(`TC-API-06 PASSED: Product added. Cart items count: ${cartBody.cart_items.length}`);
  });

  /**
   * TC-API-07: Generate an invoice using the cart from TC-API-05.
   * Verifies the invoice ID is returned in the response.
   * @regression @api
   */
  test("TC-API-07: Generate invoice via API @regression @api", async () => {
    // Fallback: read from file if running this test in isolation
    if (!cartId) {
      const saved = store.readFromFile("CartId");
      cartId = saved?.cartId;
    }
    expect(cartId).toBeTruthy();

    const headers        = cartApiPage.buildAuthHeaders(bearerToken);
    const invoicePayload = cartApiPage.buildInvoicePayload(cartId);

    const response = await api.postResponse(
      cartApiPage.invoicesEndpoint,
      invoicePayload,
      headers
    );

    expect([200, 201]).toContain(response.status());
    const body = await response.json();
    expect(body).toHaveProperty("id");

    store.saveToFile({ invoiceId: body.id }, "InvoiceId");
    console.log(`TC-API-07 PASSED: Invoice generated — invoiceId: ${body.id}`);
  });
});
