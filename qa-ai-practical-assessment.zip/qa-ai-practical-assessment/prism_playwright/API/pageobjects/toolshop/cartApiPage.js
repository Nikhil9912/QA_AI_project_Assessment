require("dotenv").config();

/**
 * API Page Object — Cart, Products, and Invoice endpoints.
 * Base: https://api.practicesoftwaretesting.com
 */
const cartApiPage = {};

cartApiPage.productsEndpoint = "products";
cartApiPage.cartsEndpoint    = "carts";
cartApiPage.invoicesEndpoint = "invoices";

/**
 * Build Authorization headers for authenticated requests.
 * @param {string} token - Bearer token obtained from login.
 */
cartApiPage.buildAuthHeaders = (token) => ({
  "Content-Type": "application/json",
  Accept: "application/json",
  Authorization: `Bearer ${token}`,
});

/** Empty body to create a new cart (API creates the cart on POST /carts). */
cartApiPage.buildCreateCartPayload = () => ({});

/**
 * Build payload for adding a product to a cart.
 * @param {string} productId - Product ID from GET /products.
 * @param {number} quantity  - Number of units to add.
 */
cartApiPage.buildAddToCartPayload = (productId, quantity) => ({
  product_id: productId,
  quantity:   quantity,
});

/**
 * Build the invoice generation payload.
 * Uses simple billing address accepted by the Toolshop API (Togo country code).
 * payment_details: {} is the correct value for cash-on-delivery (no instrument details needed).
 * @param {string} cartId - Cart ID created in TC-API-05.
 */
cartApiPage.buildInvoicePayload = (cartId) => ({
  billing_street:      "Zoey Shore",
  billing_city:        "Hesselbury",
  billing_state:       "Florida",
  billing_country:     "TG",
  billing_postal_code: "1234AA",
  payment_method:      "cash-on-delivery",
  cart_id:             cartId,
  payment_details:     {},
});

module.exports = cartApiPage;
