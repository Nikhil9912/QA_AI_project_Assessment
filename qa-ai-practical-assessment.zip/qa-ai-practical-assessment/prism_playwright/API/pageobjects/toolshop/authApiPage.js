require("dotenv").config();

/**
 * API Page Object — Authentication endpoints (register + login).
 * Base: https://api.practicesoftwaretesting.com
 *
 * Key API constraints discovered during live testing:
 *  - address must be an ARRAY of strings (plain string returns 422)
 *  - password must not be a commonly breached value (API returns 422 otherwise)
 *  - email domain @yopmail.com is accepted; @mailinator.com is blocked
 */
const authApiPage = {};

authApiPage.baseHeaders = {
  "Content-Type": "application/json",
  Accept: "application/json",
};

authApiPage.registerEndpoint = "users/register";
authApiPage.loginEndpoint    = "users/login";

/**
 * Build a valid registration payload.
 * @param {string} email - Unique email for this run.
 * @param {string} password - Breach-safe password.
 */
authApiPage.buildRegisterPayload = (email, password) => ({
  first_name: "NikhilQA",
  last_name:  "AutoTest",
  dob:        "1992-06-20",
  address:    ["99 Automation Lane"],   // Must be array — API contract requirement
  postcode:   "W1A 1AA",
  city:       "London",
  state:      "England",
  country:    "GB",
  phone:      "07700900000",
  email:      email,
  password:   password,
});

/**
 * Build a login payload.
 */
authApiPage.buildLoginPayload = (email, password) => ({
  email:    email,
  password: password,
});

module.exports = authApiPage;
