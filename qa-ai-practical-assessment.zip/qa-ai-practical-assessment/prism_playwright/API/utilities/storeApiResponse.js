const { writeFileSync, mkdirSync, existsSync } = require("fs");
const path = require("path");

/**
 * Utility to persist API response data as JSON files under API/testdata/.
 * Used for cross-test state sharing (token, cartId, invoiceId).
 */
class StoreApiResponse {
  constructor() {
    this.dataDir = path.join(__dirname, "../testdata");
    if (!existsSync(this.dataDir)) {
      mkdirSync(this.dataDir, { recursive: true });
    }
  }

  /**
   * Write a JS object to a named JSON file inside API/testdata/.
   * @param {object} data - Plain object to serialise.
   * @param {string} fileName - File name without extension.
   */
  saveToFile(data, fileName) {
    const filePath = path.join(this.dataDir, `${fileName}.json`);
    writeFileSync(filePath, JSON.stringify(data, null, 2));
    console.log(`[StoreApiResponse] Saved to ${fileName}.json`);
  }

  /**
   * Read and parse a previously saved JSON file.
   * Returns null if the file does not exist.
   * @param {string} fileName - File name without extension.
   */
  readFromFile(fileName) {
    const filePath = path.join(this.dataDir, `${fileName}.json`);
    if (!existsSync(filePath)) return null;
    return JSON.parse(require("fs").readFileSync(filePath, "utf-8"));
  }
}

module.exports = { StoreApiResponse };
