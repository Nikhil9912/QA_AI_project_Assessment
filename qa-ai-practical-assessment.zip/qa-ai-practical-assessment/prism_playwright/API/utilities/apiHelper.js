const { request } = require("@playwright/test");
require("dotenv").config();

/**
 * API Helper — thin wrapper around Playwright's APIRequestContext.
 * Creates a fresh context per call (stateless by design).
 * ignoreHTTPSErrors is mandatory on request.newContext() — the project-level
 * config option does NOT propagate to standalone API contexts.
 */
class ApiHelper {
  constructor() {}

  async getResponse(endpoint, headers) {
    const ctx = await request.newContext({
      baseURL: process.env.URL,
      ignoreHTTPSErrors: true,
    });
    const response = await ctx.get(`/${endpoint}`, { headers });
    return response;
  }

  async postResponse(endpoint, payload, headers) {
    const ctx = await request.newContext({
      baseURL: process.env.URL,
      ignoreHTTPSErrors: true,
    });
    const response = await ctx.post(`/${endpoint}`, { headers, data: payload });
    return response;
  }

  async putResponse(endpoint, payload, headers) {
    const ctx = await request.newContext({
      baseURL: process.env.URL,
      ignoreHTTPSErrors: true,
    });
    const response = await ctx.put(`/${endpoint}`, { headers, data: payload });
    return response;
  }

  async deleteResponse(endpoint, headers) {
    const ctx = await request.newContext({
      baseURL: process.env.URL,
      ignoreHTTPSErrors: true,
    });
    const response = await ctx.delete(`/${endpoint}`, { headers });
    return response;
  }
}

module.exports = { ApiHelper };
