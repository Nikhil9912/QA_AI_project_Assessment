// @ts-check
const { defineConfig } = require("@playwright/test");
require("dotenv").config();

/**
 * Toolshop QA Assessment — Playwright config
 * Browser: Microsoft Edge only (msedge channel)
 *
 * Run commands:
 *   Smoke:      npx playwright test --config=playwright.toolshop.config.js --grep @smoke
 *   Regression: npx playwright test --config=playwright.toolshop.config.js --grep @regression
 *   UI only:    npx playwright test --config=playwright.toolshop.config.js --grep @ui
 *   API only:   npx playwright test --config=playwright.toolshop.config.js --grep @api
 *   All:        npx playwright test --config=playwright.toolshop.config.js
 */
module.exports = defineConfig({
  testDir: "./tests",
  testMatch: "**/toolshop/**/*.spec.js",
  retries: 1,
  workers: 1,            // Must be 1 — API tests share state (bearerToken, cartId)
  timeout: 120 * 1000,
  expect: { timeout: 30000 },
  reporter: [
    ["html", { outputFolder: "./playwright-report-toolshop", open: "never" }],
    ["list"],
  ],
  projects: [
    {
      name: "toolshop_msedge",
      use: {
        channel: "msedge",
        headless: false,
        screenshot: "on",
        video: "retain-on-failure",  // Changed from "on" mode to avoid ffmpeg dependency
        ignoreHTTPSErrors: true,
        viewport: { width: 1280, height: 900 },
        trace: "on",
        launchOptions: { slowMo: 350 },
      },
    },
  ],
});
