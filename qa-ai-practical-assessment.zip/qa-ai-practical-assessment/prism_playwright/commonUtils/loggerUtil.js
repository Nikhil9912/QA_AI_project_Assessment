const { logger } = require("../UI/utilities/logger");

/**
 * Logger utility wrapper used by all page object classes.
 * Provides a uniform logger() method with ISO timestamp prefix.
 */
class loggerUtilities {
  constructor() {}

  /**
   * Log an informational message with a timestamp prefix.
   * @param {string} message - The message to log.
   */
  logger(message) {
    const ts = new Date().toISOString();
    logger.info(`[${ts}] ${message}`);
  }
}

module.exports = loggerUtilities;
