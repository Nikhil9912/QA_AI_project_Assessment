const { expect } = require("@playwright/test");
require("dotenv").config();
const loggerUtilities = require("../../../commonUtils/loggerUtil");

/**
 * Account Page Object — Toolshop (practicesoftwaretesting.com)
 * Covers: My Invoices and My Profile sections accessible from the user nav menu.
 */
class AccountPage {
  constructor(page) {
    this.page = page;
    this.log  = new loggerUtilities();

    this.navUserMenu    = page.locator("button[data-test='nav-menu']");
    this.invoicesLink   = page.locator("a[data-test='nav-my-invoices']");
    this.profileLink    = page.locator("a[data-test='nav-my-profile']");
    this.invoiceRows    = page.locator("table tbody tr, [data-test^='invoice-']");
    this.profileFirstName = page.locator("input[data-test='first-name']");
  }

  /** Navigate to My Invoices via the user menu dropdown. */
  async goToMyInvoices() {
    await this.navUserMenu.waitFor({ state: "visible", timeout: 10000 });
    await this.navUserMenu.click();
    await this.invoicesLink.waitFor({ state: "visible", timeout: 5000 });
    await this.invoicesLink.click();
    await this.page.waitForURL("**/invoices");
    await this.page.waitForLoadState("networkidle");
    this.log.logger("Navigated to My Invoices page");
  }

  /** Assert that at least one invoice row is present in the invoices table. */
  async verifyInvoicePresent() {
    await expect(this.invoiceRows.first()).toBeVisible({ timeout: 15000 });
    this.log.logger("Invoice row confirmed present in My Invoices");
  }

  /** Navigate to My Profile via the user menu dropdown. */
  async goToMyProfile() {
    await this.navUserMenu.waitFor({ state: "visible", timeout: 10000 });
    await this.navUserMenu.click();
    await this.profileLink.waitFor({ state: "visible", timeout: 5000 });
    await this.profileLink.click();
    await this.page.waitForLoadState("networkidle");
    this.log.logger("Navigated to My Profile page");
  }

  /**
   * Verify the first-name field on the profile page contains an expected value.
   * @param {string} expectedFirstName
   */
  async verifyProfileFirstName(expectedFirstName) {
    await expect(this.profileFirstName).toHaveValue(expectedFirstName, { timeout: 8000 });
    this.log.logger(`Profile first name verified as: ${expectedFirstName}`);
  }
}

module.exports = { AccountPage };
