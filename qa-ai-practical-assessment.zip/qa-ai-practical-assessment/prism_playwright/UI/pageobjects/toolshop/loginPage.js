const { expect } = require("@playwright/test");
require("dotenv").config();
const loggerUtilities = require("../../../commonUtils/loggerUtil");

/**
 * Login Page Object — Toolshop (practicesoftwaretesting.com)
 * URL: /auth/login
 *
 * Key selectors (all data-test based):
 *  - email input:       input[data-test='email']
 *  - password input:    input[data-test='password']
 *  - submit button:     input[data-test='login-submit']
 *  - error message:     div.alert-danger[data-test='login-error']
 *  - user nav menu:     button[data-test='nav-menu']   ← BUTTON not ANCHOR
 *  - sign-out link:     a[data-test='nav-sign-out']
 *  - sign-in link:      a[data-test='nav-sign-in']
 */
class LoginPage {
  constructor(page) {
    this.page = page;
    this.log  = new loggerUtilities();

    this.emailInput    = page.locator("input[data-test='email']");
    this.passwordInput = page.locator("input[data-test='password']");
    this.loginBtn      = page.locator("input[data-test='login-submit']");
    this.signInLink    = page.locator("a[data-test='nav-sign-in']");
    this.navUserMenu   = page.locator("button[data-test='nav-menu']");
    this.signOutLink   = page.locator("a[data-test='nav-sign-out']");
    this.loginError    = page.locator("div.alert.alert-danger[data-test='login-error']");
  }

  /** Navigate to the application home page. */
  async goto() {
    await this.page.goto(process.env.BASE_URL);
    await this.page.waitForLoadState("networkidle");
    this.log.logger("Navigated to Toolshop home page");
  }

  /** Click the sign-in link from the navbar to reach /auth/login. */
  async navigateToLogin() {
    await this.signInLink.waitFor({ state: "visible", timeout: 10000 });
    await this.signInLink.click();
    await this.page.waitForURL("**/auth/login");
    this.log.logger("Navigated to login page via navbar link");
  }

  /** Fill in credentials and submit the login form. */
  async login(email, password) {
    await this.emailInput.fill(email);
    await this.passwordInput.fill(password);
    await this.loginBtn.click();
    this.log.logger(`Login form submitted with email: ${email}`);
  }

  /** Assert the user nav-menu button is visible, confirming successful login. */
  async verifyLoginSuccess() {
    await expect(this.navUserMenu).toBeVisible({ timeout: 15000 });
    this.log.logger("Login success confirmed — nav-menu button visible");
  }

  /**
   * Assert the login error banner is visible and contains the expected message.
   * @param {string} expectedMessage - Exact text expected in the error banner.
   */
  async verifyLoginError(expectedMessage) {
    await expect(this.loginError).toBeVisible({ timeout: 10000 });
    if (expectedMessage) {
      await expect(this.loginError).toContainText(expectedMessage);
    }
    this.log.logger(`Login error verified: "${expectedMessage}"`);
  }

  /** Perform logout from the user menu dropdown. */
  async logout() {
    await this.navUserMenu.waitFor({ state: "visible", timeout: 10000 });
    await this.navUserMenu.click();
    await this.signOutLink.waitFor({ state: "visible", timeout: 5000 });
    await this.signOutLink.click();
    this.log.logger("Logout action performed via nav-menu dropdown");
  }

  /** Confirm that the sign-in link reappears after logout. */
  async verifyLogoutSuccess() {
    await expect(this.signInLink).toBeVisible({ timeout: 10000 });
    this.log.logger("Logout verified — sign-in link restored in navbar");
  }
}

module.exports = { LoginPage };
