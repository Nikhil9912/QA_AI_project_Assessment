const { expect } = require("@playwright/test");
require("dotenv").config();
const loggerUtilities = require("../../../commonUtils/loggerUtil");

/**
 * Product Page Object — Toolshop (practicesoftwaretesting.com)
 * Covers: product listing, search, product detail, add-to-cart, cart navigation.
 */
class ProductPage {
  constructor(page) {
    this.page = page;
    this.log  = new loggerUtilities();

    this.searchInput   = page.locator("input[data-test='search-query']");
    this.searchBtn     = page.locator("button[data-test='search-submit']");
    this.productLinks  = page.locator("a[data-test^='product-']");
    this.productName   = page.locator("h1[data-test='product-name']");
    this.unitPrice     = page.locator("span[data-test='unit-price']");
    this.quantityInput = page.locator("input[data-test='quantity']");
    this.addToCartBtn  = page.locator("button[data-test='add-to-cart']");
    this.navCart       = page.locator("a[data-test='nav-cart']");
    this.cartBadge     = page.locator("span[data-test='cart-quantity']");
  }

  /** Navigate to the product listing (home) page. */
  async goto() {
    await this.page.goto(process.env.BASE_URL);
    await this.page.waitForLoadState("networkidle");
    this.log.logger("Navigated to product listing page");
  }

  /**
   * Search for a product using the search bar.
   * @param {string} keyword - Search term to enter.
   */
  async searchProduct(keyword) {
    await this.searchInput.waitFor({ state: "visible", timeout: 10000 });
    await this.searchInput.fill(keyword);
    await this.searchBtn.click();
    await this.page.waitForTimeout(1500);
    this.log.logger(`Product search performed for: "${keyword}"`);
  }

  /** Click the first product card in the listing. */
  async clickFirstProduct() {
    await this.productLinks.first().waitFor({ state: "visible", timeout: 10000 });
    await this.productLinks.first().click();
    await this.page.waitForLoadState("networkidle");
    this.log.logger("Clicked first product from listing");
  }

  /**
   * Set a specific quantity in the quantity input on the product detail page.
   * @param {number} qty - Desired quantity.
   */
  async setQuantity(qty) {
    await this.quantityInput.waitFor({ state: "visible", timeout: 8000 });
    await this.quantityInput.clear();
    await this.quantityInput.fill(String(qty));
    this.log.logger(`Product quantity set to: ${qty}`);
  }

  /** Click the Add to Cart button. */
  async addToCart() {
    await this.addToCartBtn.waitFor({ state: "visible", timeout: 10000 });
    await this.addToCartBtn.click();
    await this.page.waitForTimeout(2000);
    this.log.logger("Add to Cart button clicked");
  }

  /** Assert that the cart badge becomes visible (indicating item was added). */
  async verifyCartBadgeVisible() {
    await expect(this.cartBadge).toBeVisible({ timeout: 8000 });
    this.log.logger("Cart badge visible — item confirmed in cart");
  }

  /** Click the cart icon in the navbar to navigate to the cart/checkout page. */
  async goToCart() {
    await this.navCart.click();
    await this.page.waitForURL("**/checkout");
    await this.page.waitForLoadState("networkidle");
    this.log.logger("Navigated to cart (checkout) page");
  }
}

module.exports = { ProductPage };
