const { expect } = require("@playwright/test");
require("dotenv").config();
const loggerUtilities = require("../../../commonUtils/loggerUtil");

/**
 * Register Page Object — Toolshop (practicesoftwaretesting.com)
 * URL: /auth/register
 *
 * Notes:
 *  - Country dropdown triggers a lookup that hydrates postcode/city/state fields.
 *    A brief wait after selecting country avoids stale-state fills.
 *  - Error shown for duplicate email uses .alert-danger or role=alert.
 */
class RegisterPage {
  constructor(page) {
    this.page = page;
    this.log  = new loggerUtilities();

    this.firstNameInput = page.locator("input[data-test='first-name']");
    this.lastNameInput  = page.locator("input[data-test='last-name']");
    this.dobInput       = page.locator("input[data-test='dob']");
    this.countrySelect  = page.locator("select[data-test='country']");
    this.postcodeInput  = page.locator("input[data-test='postal_code']");
    this.houseNumInput  = page.locator("input[data-test='house_number']");
    this.streetInput    = page.locator("input[data-test='street']");
    this.cityInput      = page.locator("input[data-test='city']");
    this.stateInput     = page.locator("input[data-test='state']");
    this.phoneInput     = page.locator("input[data-test='phone']");
    this.emailInput     = page.locator("input[data-test='email']");
    this.passwordInput  = page.locator("input[data-test='password']");
    this.registerBtn    = page.locator("button[data-test='register-submit']");
    this.errorAlert     = page.locator("div.alert-danger, [role='alert']");
  }

  /** Navigate directly to the registration page. */
  async navigateToRegister() {
    await this.page.goto(`${process.env.BASE_URL}/auth/register`);
    await this.page.waitForLoadState("networkidle");
    this.log.logger("Navigated to registration page");
  }

  /**
   * Fill in the complete registration form.
   * @param {object} userData - Object with firstName, lastName, dob, country,
   *                            postcode, houseNumber, street, city, state, phone,
   *                            email, password.
   */
  async fillRegistrationForm(userData) {
    await this.firstNameInput.fill(userData.firstName);
    await this.lastNameInput.fill(userData.lastName);
    await this.dobInput.fill(userData.dob);
    await this.countrySelect.selectOption(userData.country);
    await this.page.waitForTimeout(1000); // allow Angular to hydrate postcode/city after country change
    await this.postcodeInput.fill(userData.postcode);
    await this.houseNumInput.fill(userData.houseNumber);
    await this.streetInput.fill(userData.street);
    await this.cityInput.fill(userData.city);
    await this.stateInput.fill(userData.state);
    await this.phoneInput.fill(userData.phone);
    await this.emailInput.fill(userData.email);
    await this.passwordInput.fill(userData.password);
    this.log.logger(`Registration form filled for email: ${userData.email}`);
  }

  /** Click the register submit button. */
  async submitRegistration() {
    await this.registerBtn.click();
    this.log.logger("Registration form submitted");
  }

  /** Confirm registration succeeded — app redirects to /auth/login. */
  async verifyRegistrationSuccess() {
    await expect(this.page).toHaveURL(/login/, { timeout: 15000 });
    this.log.logger("Registration success — redirected to login page");
  }

  /** Confirm that a registration error is shown (e.g. duplicate email). */
  async verifyRegistrationError() {
    await expect(this.errorAlert).toBeVisible({ timeout: 8000 });
    this.log.logger("Registration error alert visible");
  }
}

module.exports = { RegisterPage };
