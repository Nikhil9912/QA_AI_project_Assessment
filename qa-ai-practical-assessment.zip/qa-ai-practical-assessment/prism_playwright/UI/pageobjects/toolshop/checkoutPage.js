const { expect } = require("@playwright/test");
require("dotenv").config();
const loggerUtilities = require("../../../commonUtils/loggerUtil");

/**
 * Checkout Page Object — Toolshop (practicesoftwaretesting.com)
 *
 * The checkout is a 4-step Angular Material stepper:
 *   Step 1 — Cart review         → proceed-1 button
 *   Step 2 — Sign-in check       → proceed-2 button (auto-passed when already logged in)
 *   Step 3 — Billing address     → proceed-3 button (DISABLED until all fields filled)
 *   Step 4 — Payment + Confirm   → payment-method select + finish button
 *
 * IMPORTANT: The Confirm (finish) button must be clicked TWICE to generate an invoice.
 *            This is expected application behaviour, not a defect.
 *            A waitForTimeout(2500) between clicks is needed to allow DOM re-render.
 *
 * Angular stepper note: inactive steps have display:none — waitFor({ state: "visible" })
 * will time out if called before the step is activated.
 */
class CheckoutPage {
  constructor(page) {
    this.page = page;
    this.log  = new loggerUtilities();

    this.proceedStep1 = page.locator("button[data-test='proceed-1']");
    this.proceedStep2 = page.locator("button[data-test='proceed-2']");
    this.proceedStep3 = page.locator("button[data-test='proceed-3']");
    this.finishBtn    = page.locator("button[data-test='finish']");

    this.countrySelect  = page.locator("select[data-test='country']");
    this.postcodeInput  = page.locator("input[data-test='postal_code']");
    this.houseNumInput  = page.locator("input[data-test='house_number']");
    this.streetInput    = page.locator("input[data-test='street']");
    this.cityInput      = page.locator("input[data-test='city']");
    this.stateInput     = page.locator("input[data-test='state']");

    this.paymentSelect = page.locator("select[data-test='payment-method']");
    this.cartTotal     = page.locator("[data-test='cart-total']");
  }

  /** Verify the cart is not empty by asserting the cart-total element is visible. */
  async verifyCartNotEmpty() {
    await expect(this.cartTotal).toBeVisible({ timeout: 10000 });
    this.log.logger("Cart total visible — cart confirmed non-empty");
  }

  /** Step 1: Proceed from cart review to sign-in step. */
  async proceedFromCart() {
    await this.proceedStep1.waitFor({ state: "visible", timeout: 15000 });
    await this.proceedStep1.click();
    await this.page.waitForTimeout(1500);
    this.log.logger("Checkout Step 1 complete — moved to sign-in step");
  }

  /** Step 2: Proceed through sign-in step (auto-skipped when already logged in). */
  async proceedFromSignIn() {
    await this.proceedStep2.waitFor({ state: "visible", timeout: 15000 });
    await this.proceedStep2.click();
    await this.page.waitForTimeout(1500);
    this.log.logger("Checkout Step 2 complete — moved to billing step");
  }

  /**
   * Step 3: Fill all billing address fields and proceed.
   * proceed-3 is disabled until all required fields contain a value.
   * @param {object} billing - Object with country, postcode, houseNumber, street, city, state.
   */
  async fillBillingAndProceed(billing) {
    await this.countrySelect.waitFor({ state: "visible", timeout: 15000 });
    await this.countrySelect.selectOption(billing.country || "US");
    await this.page.waitForTimeout(900); // allow Angular form validators to update

    await this.postcodeInput.fill(billing.postcode    || "90210");
    await this.houseNumInput.fill(billing.houseNumber || "15");
    await this.streetInput.fill(billing.street        || "Cypress Drive");
    await this.cityInput.fill(billing.city            || "Beverly Hills");
    await this.stateInput.fill(billing.state          || "CA");
    this.log.logger("Billing address fields filled");

    await expect(this.proceedStep3).toBeEnabled({ timeout: 6000 });
    await this.proceedStep3.click();
    await this.page.waitForTimeout(1500);
    this.log.logger("Checkout Step 3 complete — billing submitted");
  }

  /**
   * Step 4: Select the payment method from the dropdown.
   * @param {string} method - Payment method value (e.g. "cash-on-delivery").
   */
  async selectPaymentMethod(method) {
    await this.paymentSelect.waitFor({ state: "visible", timeout: 15000 });
    await this.paymentSelect.selectOption(method);
    this.log.logger(`Payment method selected: ${method}`);
  }

  /**
   * Confirm the order by clicking the Finish button TWICE.
   * First click queues the order; second click generates the invoice.
   * A 2500ms pause between clicks allows the DOM to update between transitions.
   */
  async confirmOrder() {
    await this.finishBtn.waitFor({ state: "visible", timeout: 15000 });
    await this.finishBtn.click();
    this.log.logger("Confirm button clicked (1st time — order queued)");
    await this.page.waitForTimeout(2500);
    await this.finishBtn.click();
    this.log.logger("Confirm button clicked (2nd time — invoice generated)");
  }

  /**
   * Verify order success after the double-confirm.
   * The app shows a success message inline on the /checkout page.
   */
  async verifyOrderSuccess() {
    await this.page.waitForTimeout(4000);
    const currentUrl = this.page.url();
    const successVisible = await this.page
      .locator("h2:has-text('Payment'), .alert-success, [data-test='order-confirmation']")
      .isVisible()
      .catch(() => false);
    const validUrl = /invoice|order|checkout|confirm/.test(currentUrl);
    this.log.logger(`Order success check — URL: ${currentUrl} | inline success: ${successVisible}`);
    expect(successVisible || validUrl).toBeTruthy();
  }
}

module.exports = { CheckoutPage };
