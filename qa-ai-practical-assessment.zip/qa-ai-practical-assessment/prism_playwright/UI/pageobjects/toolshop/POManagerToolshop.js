const { LoginPage }    = require("./loginPage");
const { RegisterPage } = require("./registerPage");
const { ProductPage }  = require("./productPage");
const { CheckoutPage } = require("./checkoutPage");
const { AccountPage }  = require("./accountPage");

/**
 * Page Object Manager — Toolshop QA Assessment.
 *
 * Centralises instantiation of all page objects.
 * Tests create a single POManagerToolshop instance in beforeEach
 * and retrieve individual pages via the getter methods.
 */
class POManagerToolshop {
  constructor(page) {
    this.page         = page;
    this.loginPage    = new LoginPage(page);
    this.registerPage = new RegisterPage(page);
    this.productPage  = new ProductPage(page);
    this.checkoutPage = new CheckoutPage(page);
    this.accountPage  = new AccountPage(page);
  }

  getLoginPage()    { return this.loginPage; }
  getRegisterPage() { return this.registerPage; }
  getProductPage()  { return this.productPage; }
  getCheckoutPage() { return this.checkoutPage; }
  getAccountPage()  { return this.accountPage; }
}

module.exports = { POManagerToolshop };
