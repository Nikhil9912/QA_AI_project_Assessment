const { createLogger, transports, format } = require("winston");

/**
 * Winston logger instance used by loggerUtil across all page objects.
 * Outputs timestamped messages to console.
 */
const logger = createLogger({
  level: "info",
  format: format.combine(
    format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    format.printf(({ timestamp, level, message }) => `[${timestamp}] [${level.toUpperCase()}] ${message}`)
  ),
  transports: [new transports.Console()],
});

module.exports = { logger };
