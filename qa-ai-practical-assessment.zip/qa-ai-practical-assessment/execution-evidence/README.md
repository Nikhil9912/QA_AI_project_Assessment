# Execution Evidence — Toolshop QA Assessment

## Summary

| Metric | Value |
|---|---|
| Total Tests | 15 (8 UI + 7 API) |
| Passed | 15 |
| Failed | 0 |
| Browser | Microsoft Edge (msedge channel) |
| Config | playwright.toolshop.config.js |
| Run Command | `npx playwright test --config=playwright.toolshop.config.js` |
| Approximate Duration | ~5–6 minutes (sequential, workers=1) |

---

## Test Results

| Test ID | Title | Layer | Tags | Result |
|---|---|---|---|---|
| TC-UI-01 | Verify login succeeds with valid credentials | UI | @smoke @regression | ✅ PASSED |
| TC-UI-02 | Verify error displayed for invalid credentials | UI | @regression | ✅ PASSED |
| TC-UI-03 | Verify login blocked when email is empty | UI | @regression | ✅ PASSED |
| TC-UI-04 | Verify new user registration with valid details | UI | @smoke @regression | ✅ PASSED |
| TC-UI-05 | Verify registration fails for duplicate email | UI | @regression | ✅ PASSED |
| TC-UI-06 | E2E — search, checkout with Cash on Delivery, verify invoice | UI | @smoke @regression | ✅ PASSED |
| TC-UI-07 | Verify cart displays product and total after add-to-cart | UI | @regression | ✅ PASSED |
| TC-UI-08 | Verify user can logout and sign-in link is restored | UI | @smoke @regression | ✅ PASSED |
| TC-API-01 | Register new user via API | API | @smoke @regression | ✅ PASSED |
| TC-API-02 | Login and obtain bearer token | API | @smoke @regression | ✅ PASSED |
| TC-API-03 | Login with invalid credentials returns 401 | API | @regression | ✅ PASSED |
| TC-API-04 | Retrieve product list via API | API | @smoke @regression | ✅ PASSED |
| TC-API-05 | Create new cart via API | API | @smoke @regression | ✅ PASSED |
| TC-API-06 | Add product to cart and verify cart contents | API | @regression | ✅ PASSED |
| TC-API-07 | Generate invoice via API | API | @regression | ✅ PASSED |

---

## Evidence Locations

| Evidence Type | Location | Description |
|---|---|---|
| HTML Report | `prism_playwright/playwright-report-toolshop/index.html` | Interactive report — open with `npm run report` |
| Screenshots | `prism_playwright/test-results/*/` | End-state screenshot per test (`.png`) |
| Videos | `prism_playwright/test-results/*/` | Full recording per UI test (`.webm`) |
| Traces | `prism_playwright/test-results/*/trace.zip` | Step-by-step DOM + network trace |
| API Response Files | `prism_playwright/API/testdata/` | Stored tokens, cart IDs, invoice IDs (`.json`) |

### Open the HTML Report
```bash
cd prism_playwright
npm run report
# or directly:
npx playwright show-report playwright-report-toolshop
```

### Open a Trace
```bash
cd prism_playwright
npx playwright show-trace "test-results/<test-folder>/trace.zip"
```

---

## Stored API Response Files

These files are written during test execution as evidence of successful API operations:

| File | Contents |
|---|---|
| `API/testdata/RegisteredUser.json` | `{ "registeredEmail": "...", "registeredPassword": "..." }` |
| `API/testdata/AccessToken.json` | `{ "access_token": "eyJ0eXAiOi..." }` |
| `API/testdata/CartId.json` | `{ "cartId": "01..." }` |
| `API/testdata/InvoiceId.json` | `{ "invoiceId": "01..." }` |

---

## Notes

- **retries: 1** — configured in playwright.toolshop.config.js. A retry-pass is still a pass and is labelled as such in the HTML report. This accounts for Edge cold-start flakiness.
- **workers: 1** — API tests share `bearerToken` and `cartId` via describe scope. Parallel execution is not safe for this suite.
- **Double-confirm** — TC-UI-06 clicks the Confirm button twice with a 2500ms pause between clicks. This is expected application behaviour, not a defect.
- **Screenshot/video/trace** are all set to `"on"` (not `"only-on-failure"`) — every test has full evidence regardless of pass/fail status.
