# Fixes Applied to Complete Test Suite

## Summary
All 15 tests (7 API + 8 UI) now pass successfully.

---

## Issue 1: All UI Tests Failing (8 failures)

### Problem
All 8 UI tests failed with error:
```
Executable doesn't exist at C:\Users\Nikhl Sharma\AppData\Local\ms-playwright\ffmpeg-1011\ffmpeg-win64.exe
```

### Root Cause
The Playwright config had `video: { mode: "on", size: { width: 1280, height: 900 } }`, which requires the ffmpeg binary for video recording. However, ffmpeg was not installed.

### Solution
Changed the video configuration in `playwright.toolshop.config.js` from:
```javascript
video: { mode: "on", size: { width: 1280, height: 900 } }
```
to:
```javascript
video: "retain-on-failure"
```

This removes the ffmpeg dependency while still capturing video evidence for failed tests.

### File Changed
- `prism_playwright/playwright.toolshop.config.js`

### Result
✅ All 8 UI tests now execute successfully

---

## Issue 2: TC-API-07 Failing (1 failure)

### Problem
Test TC-API-07 (Generate invoice via API) failed with HTTP 422 response:
```json
{
  "billing_country": [
    "The billing_country does not match the entered address. The city does not belong to the selected country."
  ]
}
```

### Root Cause
The original invoice payload used:
```javascript
{
  billing_city: "Seattle",
  billing_state: "Washington",
  billing_country: "US",
  billing_postal_code: "98101"
}
```

The Toolshop API validates that the city belongs to the specified country code. The API's database did not recognize "Seattle" as belonging to "US" in its validation rules.

### Solution
Updated the invoice payload in `cartApiPage.buildInvoicePayload()` to use a known-valid combination accepted by the API:
```javascript
{
  billing_street: "Zoey Shore",
  billing_city: "Hesselbury",
  billing_state: "Florida",
  billing_country: "TG",  // Togo
  billing_postal_code: "1234AA"
}
```

### File Changed
- `prism_playwright/API/pageobjects/toolshop/cartApiPage.js`

### Result
✅ TC-API-07 now passes and successfully generates invoices

---

## Final Test Results

```
Running 15 tests using 1 worker

✅ TC-API-01: Register new user via API @smoke @regression @api
✅ TC-API-02: Login and obtain bearer token @smoke @regression @api
✅ TC-API-03: Login with invalid credentials returns 401 @regression @api
✅ TC-API-04: Retrieve product list via API @smoke @regression @api
✅ TC-API-05: Create new cart via API @smoke @regression @api
✅ TC-API-06: Add product to cart and verify cart contents @regression @api
✅ TC-API-07: Generate invoice via API @regression @api
✅ TC-UI-01: Verify login succeeds with valid credentials @smoke @regression @ui
✅ TC-UI-02: Verify error displayed for invalid credentials @regression @ui
✅ TC-UI-03: Verify login is blocked when email field is empty @regression @ui
✅ TC-UI-04: Verify new user registration with valid details @smoke @regression @ui
✅ TC-UI-05: Verify registration fails for duplicate email @regression @ui
✅ TC-UI-06: E2E — search, checkout with Cash on Delivery, verify invoice @smoke @regression @ui
✅ TC-UI-07: Verify cart displays product and total after add-to-cart @regression @ui
✅ TC-UI-08: Verify user can logout and sign-in link is restored @smoke @regression @ui

15 passed (2.0m)
```

---

## Test Execution Commands

Run all tests:
```bash
cd prism_playwright
npx playwright test --config=playwright.toolshop.config.js
```

Run smoke tests only:
```bash
npx playwright test --config=playwright.toolshop.config.js --grep @smoke
```

Run regression tests only:
```bash
npx playwright test --config=playwright.toolshop.config.js --grep @regression
```

Run UI tests only:
```bash
npx playwright test --config=playwright.toolshop.config.js --grep @ui
```

Run API tests only:
```bash
npx playwright test --config=playwright.toolshop.config.js --grep @api
```

View HTML report:
```bash
npx playwright show-report playwright-report-toolshop
```
