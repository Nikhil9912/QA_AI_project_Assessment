# QA AI Capability Exercise — Part A: AI Workflow Foundation

## 1. What the Project Is About

This project involves building and demonstrating an AI-assisted QA testing workflow using **Playwright** as the automation framework and **Cursor AI** as the primary AI tool. The system under test (SUT) is a realistic web application with both UI and API surfaces — covering typical flows like user authentication, form submission, data retrieval, and CRUD operations via REST APIs.

The goal is to show end-to-end test coverage across UI and API layers, while making the testing thought process visible: how requirements are analyzed, how test strategy is formed, how test cases are designed, and how automation is structured — all with meaningful AI assistance at each stage.

---

## 2. Primary AI Tool(s) Used

- **Cursor AI** — main tool for requirement analysis, test design, automation scripting, and debugging within the IDE
- **ChatGPT** — used for higher-level planning, test strategy discussion, and generating varied test data sets outside the codebase

---

## 3. How Project and SUT Context Is Provided to the AI

Before prompting for any test-related output, I establish context explicitly:

- Paste or reference the relevant user story, acceptance criteria, or API contract (e.g., OpenAPI spec excerpt)
- Describe the tech stack: "This is a Next.js frontend with a Node/Express REST API; tests use Playwright with TypeScript"
- Describe the environment: base URL, auth mechanism (e.g., JWT via login endpoint), any known test data constraints
- Share the folder/file structure of the test project so Cursor understands naming conventions and where things live

This prevents generic output and keeps suggestions aligned with the actual project structure.

---

## 4. How AI Is Used for Requirement Analysis

- Feed user stories or acceptance criteria into Cursor/ChatGPT and ask it to identify testable conditions, ambiguities, and missing edge cases
- Ask: *"Given this acceptance criterion, what scenarios would a QA engineer typically miss on first pass?"*
- Use AI to surface implicit requirements — e.g., error states, permission boundaries, pagination edge cases — that aren't explicitly stated
- Cross-check AI output against the original requirement and flag anything that seems like an assumption rather than a stated requirement

---

## 5. How AI Is Used for Test Planning and Strategy

- Provide the feature scope and ask AI to suggest a test pyramid breakdown: what belongs in unit, integration, API, and E2E layers
- Define smoke vs. regression scope by asking: *"Which of these scenarios are critical-path and should be in a smoke suite?"*
- Use AI to help prioritize based on risk: high-traffic flows, payment/auth paths, and data-mutation operations get deeper coverage
- For UI vs. API split: use AI to identify which test cases are better validated at the API layer (faster, more stable) vs. those that need UI-level verification (visual flow, browser behavior)

---

## 6. How AI Is Used for Manual Test Case Design

- Prompt AI with a specific feature and ask for functional, negative, edge case, and boundary test cases separately — not all at once
- Example prompt: *"Write negative test cases for a login form that uses email/password auth. Cover input validation, account states, and server error scenarios."*
- Review each generated test case against the acceptance criteria — remove or rewrite anything that tests behavior not specified or not relevant
- Add non-functional cases (e.g., response time thresholds, accessibility checks) manually, using AI to suggest what to check rather than write the full case

---

## 7. How AI Is Used for Automation Design

- Use Cursor to scaffold the Playwright project structure: page objects, fixtures, helper utilities, and config files
- Ask AI to suggest reusable patterns for common actions (e.g., login utility, API auth token fixture, custom expect matchers)
- When designing a new test file, describe the scenario in a comment block and ask Cursor to generate the skeleton — then review and fill in assertions manually
- Use AI to enforce consistency: paste an existing test and ask *"Write a new test for [feature] that follows the same structure and style"*

---

## 8. How AI Is Used for Test Data Generation

- Ask AI to generate realistic but fake data sets for forms, API payloads, and edge case inputs (e.g., Unicode names, max-length strings, special characters)
- For API tests, provide the endpoint schema and ask AI to generate valid, invalid, and boundary-value payloads
- Use AI to suggest data combinations for parameterized tests (e.g., different user roles, plan types, locale settings)
- Never use real user data or production data — all test data is synthetic or anonymized

---

## 9. How AI Is Used for Debugging Failing Tests

- Paste the failing test, the error output, and relevant logs into Cursor and ask for a diagnosis
- Ask specifically: *"What are the most likely causes of this Playwright timeout on this selector?"* rather than *"Fix this"*
- Use AI to interpret Playwright trace viewer output or network logs when the failure isn't obvious
- If AI suggests a fix, understand why before applying it — if the explanation doesn't make sense, ask for clarification before changing code

---

## 10. What Information Is Avoided When Using AI Tools

- No real credentials, API keys, or tokens are shared — placeholders are used (e.g., `process.env.TEST_USER_EMAIL`)
- No production URLs, internal system names, or client-identifying details
- No PII from real users — all names, emails, and IDs used in prompts are synthetic
- No proprietary business logic or confidential product specs beyond what's needed to describe a test scenario
- Cursor's codebase indexing is limited to the test project folder, not the full application source

---

## 11. How This QA Workflow Would Be Reused on a Real Project

This workflow is designed to be repeatable across projects:

1. **Onboarding a new SUT**: establish context doc (tech stack, auth, API contracts, test scope) → use AI to generate initial test plan
2. **Feature work**: feed acceptance criteria to AI → generate manual test cases → review and refine → automate critical paths in Playwright
3. **Regression maintenance**: use AI to identify which existing tests are affected by a change → update selectors or assertions with Cursor assistance
4. **Debugging**: structured prompt pattern (test + error + logs) → AI diagnosis → human-verified fix
5. **Documentation**: use AI to generate test run summaries and coverage notes from test results

The key principle throughout: AI accelerates and suggests, but a QA engineer owns the decisions — on coverage, on what to automate, on what a failure actually means.
