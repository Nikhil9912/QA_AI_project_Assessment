import { Page, expect } from '@playwright/test';

export class LoginPage {
  constructor(private page: Page) {}

  async goto() {
    await this.page.goto('/auth/login');
  }

  async login(email: string, password: string) {
    await this.page.getByTestId('email').fill(email);
    await this.page.getByTestId('password').fill(password);
    await this.page.getByTestId('login-submit').click();
  }

  async expectErrorVisible() {
    await expect(this.page.getByTestId('login-error')).toBeVisible();
  }

  async expectLoggedIn() {
    // After login, nav shows account menu or "My Account" link
    await expect(this.page.locator('nav')).toContainText('John');
  }
}
