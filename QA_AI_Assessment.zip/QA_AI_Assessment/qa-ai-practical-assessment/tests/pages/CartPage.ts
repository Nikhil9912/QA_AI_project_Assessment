import { Page, expect } from '@playwright/test';

export class CartPage {
  constructor(private page: Page) {}

  async goto() {
    await this.page.goto('/checkout');
  }

  async updateQuantity(index: number, qty: number) {
    const qtyInput = this.page.locator('[data-test="product-quantity"]').nth(index);
    await qtyInput.fill(String(qty));
    await qtyInput.press('Enter');
  }

  async proceedToCheckout() {
    await this.page.getByTestId('proceed-1').click();
    await this.page.getByTestId('proceed-2').click();
  }

  async fillPaymentCashOnDelivery() {
    await this.page.getByTestId('payment-method').selectOption('Cash on Delivery');
    await this.page.getByTestId('finish').click();
  }

  async confirmOrder() {
    await this.page.getByTestId('confirm-btn').click();
  }

  async expectOrderConfirmed() {
    await expect(this.page.locator('.alert-success, [data-test="order-confirmation"]')).toBeVisible();
  }
}
