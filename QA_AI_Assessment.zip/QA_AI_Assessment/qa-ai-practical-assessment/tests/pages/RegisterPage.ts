import { Page, expect } from '@playwright/test';

export class RegisterPage {
  constructor(private page: Page) {}

  async goto() {
    await this.page.goto('/auth/register');
  }

  async register(details: {
    firstName: string;
    lastName: string;
    dob: string;
    address: string;
    postcode: string;
    city: string;
    state: string;
    country: string;
    phone: string;
    email: string;
    password: string;
  }) {
    await this.page.getByTestId('first-name').fill(details.firstName);
    await this.page.getByTestId('last-name').fill(details.lastName);
    await this.page.getByTestId('dob').fill(details.dob);
    await this.page.getByTestId('address').fill(details.address);
    await this.page.getByTestId('postcode').fill(details.postcode);
    await this.page.getByTestId('city').fill(details.city);
    await this.page.getByTestId('state').fill(details.state);
    await this.page.getByLabel('Country *').selectOption(details.country);
    await this.page.getByTestId('phone').fill(details.phone);
    await this.page.getByTestId('email').fill(details.email);
    await this.page.getByTestId('password').fill(details.password);
    await this.page.getByTestId('register-submit').click();
  }

  async expectSuccessRedirect() {
    await expect(this.page).toHaveURL(/auth\/login/);
  }

  async expectValidationErrors() {
    await expect(this.page.locator('.alert, [data-test*="error"]').first()).toBeVisible();
  }
}
