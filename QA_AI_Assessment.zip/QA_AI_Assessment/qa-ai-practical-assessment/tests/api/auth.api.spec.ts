import { test, expect, request } from '@playwright/test';

const API_BASE = process.env.API_BASE_URL ?? 'https://api.practicesoftwaretesting.com';
const EMAIL = process.env.TEST_USER_EMAIL ?? 'customer@practicesoftwaretesting.com';
const PASSWORD = process.env.TEST_USER_PASSWORD ?? 'welcome01';
const uniqueEmail = `api_user_${Date.now()}@mailtest.com`;

test.describe('API — User Auth', () => {

  test('TC-API-01 @smoke — POST /users/login returns 200 and access_token', async () => {
    const ctx = await request.newContext({ baseURL: API_BASE });

    const res = await ctx.post('/users/login', {
      data: { email: EMAIL, password: PASSWORD },
    });

    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body).toHaveProperty('access_token');
    expect(typeof body.access_token).toBe('string');
    expect(body.access_token.length).toBeGreaterThan(0);

    await ctx.dispose();
  });

  test('TC-API-02 @smoke — POST /users/login with wrong password returns 401', async () => {
    const ctx = await request.newContext({ baseURL: API_BASE });

    const res = await ctx.post('/users/login', {
      data: { email: EMAIL, password: 'wrongpassword' },
    });

    expect(res.status()).toBe(401);

    await ctx.dispose();
  });

  test('TC-API-03 @regression — POST /users/register creates a new user and returns 201', async () => {
    const ctx = await request.newContext({ baseURL: API_BASE });

    const res = await ctx.post('/users/register', {
      data: {
        first_name: 'Test',
        last_name: 'Automation',
        dob: '1990-01-15',
        address: '123 Test Street',
        postcode: '12345',
        city: 'Testville',
        state: 'TestState',
        country: 'US',
        phone: '0600000001',
        email: uniqueEmail,
        password: 'SecurePass1!',
      },
    });

    expect(res.status()).toBe(201);
    const body = await res.json();
    expect(body).toHaveProperty('id');
    expect(body.email).toBe(uniqueEmail);

    await ctx.dispose();
  });

});
