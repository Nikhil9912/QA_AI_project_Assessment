import { test, expect, request } from '@playwright/test';

const API_BASE = process.env.API_BASE_URL ?? 'https://api.practicesoftwaretesting.com';
const EMAIL = process.env.TEST_USER_EMAIL ?? 'customer@practicesoftwaretesting.com';
const PASSWORD = process.env.TEST_USER_PASSWORD ?? 'welcome01';

/**
 * Shared state within this suite — token, cartId, productId
 * populated step-by-step to reflect a realistic user flow.
 */
let token: string;
let cartId: string;
let productId: string;

test.describe('API — Cart & Invoice Flow', () => {

  test.beforeAll(async () => {
    const ctx = await request.newContext({ baseURL: API_BASE });
    const res = await ctx.post('/users/login', {
      data: { email: EMAIL, password: PASSWORD },
    });
    const body = await res.json();
    token = body.access_token;
    await ctx.dispose();
  });

  test('TC-API-04 @smoke — POST /carts creates a new cart and returns cart id', async () => {
    const ctx = await request.newContext({ baseURL: API_BASE });

    const res = await ctx.post('/carts', {
      headers: { Authorization: `Bearer ${token}` },
    });

    expect(res.status()).toBe(201);
    const body = await res.json();
    expect(body).toHaveProperty('id');
    cartId = body.id;

    await ctx.dispose();
  });

  test('TC-API-05 @smoke — GET /products returns product list with required fields', async () => {
    const ctx = await request.newContext({ baseURL: API_BASE });

    const res = await ctx.get('/products?between=price,1,200&page=1');

    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body).toHaveProperty('data');
    expect(Array.isArray(body.data)).toBe(true);
    expect(body.data.length).toBeGreaterThan(0);

    // Capture a product id for next step
    productId = body.data[0].id;
    expect(typeof productId).toBe('string');

    // Verify product shape
    const product = body.data[0];
    expect(product).toHaveProperty('name');
    expect(product).toHaveProperty('price');
    expect(product).toHaveProperty('in_stock');

    await ctx.dispose();
  });

  test('TC-API-06 @regression — POST /carts/:id/add-product adds item and validates cart payload', async () => {
    const ctx = await request.newContext({ baseURL: API_BASE });

    const res = await ctx.post(`/carts/${cartId}`, {
      headers: { Authorization: `Bearer ${token}` },
      data: { product_id: productId, quantity: 2 },
    });

    expect(res.status()).toBe(201);
    const body = await res.json();

    // Cart payload structure assertions
    expect(body).toHaveProperty('id');
    expect(Array.isArray(body.cart_items)).toBe(true);
    expect(body.cart_items.length).toBeGreaterThan(0);

    const addedItem = body.cart_items.find((i: { product_id: string }) => i.product_id === productId);
    expect(addedItem).toBeDefined();
    expect(addedItem.quantity).toBe(2);

    await ctx.dispose();
  });

  test('TC-API-07 @regression — POST /invoices generates invoice from active cart', async () => {
    const ctx = await request.newContext({ baseURL: API_BASE });

    const res = await ctx.post('/invoices', {
      headers: { Authorization: `Bearer ${token}` },
      data: {
        cart_id: cartId,
        billing_address: '123 Test Street',
        billing_city: 'Testville',
        billing_state: 'TestState',
        billing_postcode: '12345',
        billing_country: 'US',
        payment_method: 'Cash on Delivery',
      },
    });

    expect([200, 201]).toContain(res.status());
    const body = await res.json();

    expect(body).toHaveProperty('id');
    expect(body).toHaveProperty('invoice_number');
    expect(body.status).toMatch(/pending|awaiting/i);

    await ctx.dispose();
  });

});
