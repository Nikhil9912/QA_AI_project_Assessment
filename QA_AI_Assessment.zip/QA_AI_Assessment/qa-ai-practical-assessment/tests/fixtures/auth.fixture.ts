import { test as base, request } from '@playwright/test';

const API_BASE = process.env.API_BASE_URL ?? 'https://api.practicesoftwaretesting.com';
const EMAIL = process.env.TEST_USER_EMAIL ?? 'customer@practicesoftwaretesting.com';
const PASSWORD = process.env.TEST_USER_PASSWORD ?? 'welcome01';

/**
 * Extended fixture that provides a Bearer token and cartId
 * pre-created for each API test, avoiding duplicate login logic.
 */
export const test = base.extend<{ token: string; cartId: string }>({
  token: async ({}, use) => {
    const ctx = await request.newContext({ baseURL: API_BASE });
    const res = await ctx.post('/users/login', {
      data: { email: EMAIL, password: PASSWORD },
    });
    const body = await res.json();
    await ctx.dispose();
    await use(body.access_token as string);
  },

  cartId: async ({ token }, use) => {
    const ctx = await request.newContext({ baseURL: API_BASE });
    const res = await ctx.post('/carts', {
      headers: { Authorization: `Bearer ${token}` },
    });
    const body = await res.json();
    await ctx.dispose();
    await use(body.id as string);
  },
});

export { expect } from '@playwright/test';
export { API_BASE, EMAIL, PASSWORD };
