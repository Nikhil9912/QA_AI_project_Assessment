import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { RegisterPage } from '../pages/RegisterPage';

const EMAIL = process.env.TEST_USER_EMAIL ?? 'customer@practicesoftwaretesting.com';
const PASSWORD = process.env.TEST_USER_PASSWORD ?? 'welcome01';

// Generate a unique email per run so registration doesn't collide
const uniqueEmail = `testuser_${Date.now()}@mailtest.com`;

test.describe('User Authentication', () => {

  test('TC-UI-01 @smoke — valid login navigates to home and shows user name', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(EMAIL, PASSWORD);

    // Logged-in state: nav contains account link or user name
    await expect(page.locator('nav')).toContainText(/account|jane/i, { ignoreCase: true });
    await expect(page).not.toHaveURL(/auth\/login/);
  });

  test('TC-UI-02 @smoke — invalid credentials show error message', async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login('notauser@fake.com', 'wrongpassword');

    await expect(
      page.locator('[data-test="login-error"], .alert-danger').first()
    ).toBeVisible();
  });

  test('TC-UI-03 @regression — new user registration succeeds and redirects to login', async ({ page }) => {
    const registerPage = new RegisterPage(page);
    await registerPage.goto();
    await registerPage.register({
      firstName: 'Test',
      lastName: 'User',
      dob: '1990-01-15',
      address: '123 Main Street',
      postcode: '12345',
      city: 'Springfield',
      state: 'IL',
      country: 'US',
      phone: '0612345678',
      email: uniqueEmail,
      password: 'SecurePass1!',
    });

    await registerPage.expectSuccessRedirect();
  });

});
