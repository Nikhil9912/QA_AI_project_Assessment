import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { CartPage } from '../pages/CartPage';

const EMAIL = process.env.TEST_USER_EMAIL ?? 'customer@practicesoftwaretesting.com';
const PASSWORD = process.env.TEST_USER_PASSWORD ?? 'welcome01';

/**
 * TC-UI-04 & TC-UI-05: E2E Purchase & Checkout Flow
 * Steps:
 *  1. Log in via LoginPage POM
 *  2. Search for a product and add to cart
 *  3. Update quantity in cart via CartPage POM
 *  4. Checkout with Cash on Delivery (two-step confirm)
 *  5. Validate invoice appears under My Invoices
 */
test.describe('E2E Checkout Flow', () => {

  test.beforeEach(async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(EMAIL, PASSWORD);
    // Confirm logged-in state before each test
    await expect(page.locator('nav')).toContainText(/account|jane/i, { ignoreCase: true });
  });

  test('TC-UI-04 @smoke — add product to cart and complete Cash on Delivery checkout', async ({ page }) => {
    const cartPage = new CartPage(page);

    // 1. Search for a product and add to cart
    await page.goto('/');
    await page.getByTestId('search-query').fill('Hammer');
    await page.getByTestId('search-submit').click();
    await page.locator('[data-test="product-name"]').first().click();
    await page.getByTestId('add-to-cart').click();

    // 2. Open cart, update quantity
    await cartPage.goto();
    await expect(page.locator('[data-test="product-title"]').first()).toBeVisible();
    await cartPage.updateQuantity(0, 2);

    // 3. Proceed through checkout steps
    await cartPage.proceedToCheckout();

    // 4. Select Cash on Delivery and confirm (two-step)
    await cartPage.fillPaymentCashOnDelivery();
    await cartPage.confirmOrder();

    await cartPage.expectOrderConfirmed();
  });

  test('TC-UI-05 @regression — invoice appears under My Invoices after order completion', async ({ page }) => {
    const cartPage = new CartPage(page);

    // Quick order: first product on homepage
    await page.goto('/');
    await page.locator('[data-test="product-name"]').first().click();
    await page.getByTestId('add-to-cart').click();

    await cartPage.goto();
    await cartPage.proceedToCheckout();
    await cartPage.fillPaymentCashOnDelivery();
    await cartPage.confirmOrder();

    // Navigate to My Invoices and verify an entry exists
    await page.goto('/account/invoices');
    await expect(
      page.locator('[data-test="invoice-id"], tbody tr').first()
    ).toBeVisible({ timeout: 10_000 });
  });

});
