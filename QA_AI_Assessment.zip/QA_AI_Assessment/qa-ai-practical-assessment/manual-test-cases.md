# Manual Test Cases — practicesoftwaretesting.com

**SUT:** https://practicesoftwaretesting.com  
**API:** https://api.practicesoftwaretesting.com  
**Scope:** User Auth, Registration, E2E Checkout, Invoice Verification  
**Test Types:** Functional, Negative, Edge Case  

---

## Module 1: User Registration & Login

### MTC-01 — Valid Login (Functional) @smoke
**Precondition:** Existing account — customer@practicesoftwaretesting.com / welcome01  
**Steps:**
1. Navigate to `/auth/login`
2. Enter valid email and password
3. Click Sign In

**Expected:** User is redirected away from login page; nav displays user's name or "My Account" link  
**Priority:** High

---

### MTC-02 — Invalid Credentials Show Error (Negative) @smoke
**Precondition:** None  
**Steps:**
1. Navigate to `/auth/login`
2. Enter `notauser@fake.com` and `wrongpassword`
3. Click Sign In

**Expected:** Error message visible on page; user remains on login page; no token issued  
**Priority:** High

---

### MTC-03 — Login with Empty Fields (Negative / Edge)
**Steps:**
1. Navigate to `/auth/login`
2. Leave email and password blank
3. Click Sign In

**Expected:** Inline validation messages appear on required fields; form not submitted  
**Priority:** Medium

---

### MTC-04 — Successful New User Registration (Functional) @regression
**Precondition:** Unique email not previously registered  
**Steps:**
1. Navigate to `/auth/register`
2. Fill all required fields with valid data
3. Click Register

**Expected:** Redirect to `/auth/login`; success confirmation visible  
**Priority:** High

---

### MTC-05 — Registration with Duplicate Email (Negative)
**Steps:**
1. Navigate to `/auth/register`
2. Enter an email already registered (e.g., customer@practicesoftwaretesting.com)
3. Fill remaining fields and click Register

**Expected:** Error message indicating email already exists; user not created  
**Priority:** High

---

### MTC-06 — Registration with Invalid Password Format (Edge)
**Steps:**
1. Navigate to `/auth/register`
2. Enter a password that does not meet requirements (e.g., `abc`)
3. Fill remaining fields and click Register

**Expected:** Validation error on password field; registration blocked  
**Priority:** Medium

---

## Module 2: E2E Purchase & Checkout

### MTC-07 — Add Product to Cart and Complete Checkout via Cash on Delivery (Functional / E2E) @smoke
**Precondition:** Logged in as customer  
**Steps:**
1. Search for "Hammer" on homepage
2. Click first search result
3. Click Add to Cart
4. Navigate to `/checkout`
5. Update item quantity to 2
6. Click Proceed (step 1)
7. Click Proceed (step 2)
8. Select "Cash on Delivery" from payment method dropdown
9. Click Finish
10. Click Confirm

**Expected:** Order confirmation message visible; no payment error  
**Priority:** High

---

### MTC-08 — Cart Quantity Update Reflects Correct Totals (Functional)
**Precondition:** At least one item in cart  
**Steps:**
1. Navigate to `/checkout`
2. Change quantity from 1 to 3 for first item
3. Observe subtotal and total fields

**Expected:** Subtotal updates to reflect qty × unit price; total recalculates  
**Priority:** Medium

---

### MTC-09 — Checkout with Empty Cart (Negative)
**Precondition:** No items in cart  
**Steps:**
1. Navigate directly to `/checkout`

**Expected:** Empty cart message visible; Proceed button absent or disabled  
**Priority:** Medium

---

### MTC-10 — Invoice Visible Under My Invoices After Successful Order (Functional) @regression
**Precondition:** At least one completed order in current session  
**Steps:**
1. Complete checkout flow (MTC-07)
2. Navigate to `/account/invoices`

**Expected:** The new invoice appears in the list with an invoice number and status  
**Priority:** High

---

## Module 3: API — Auth & Cart (Reference for Automation)

| ID | Endpoint | Type | Scenario | Expected |
|----|----------|------|----------|----------|
| MTC-API-01 | POST /users/login | Functional | Valid credentials | 200, access_token in body |
| MTC-API-02 | POST /users/login | Negative | Wrong password | 401 Unauthorized |
| MTC-API-03 | POST /users/register | Functional | New unique user | 201, user id in body |
| MTC-API-04 | POST /carts | Functional | Authenticated user creates cart | 201, cart id returned |
| MTC-API-05 | GET /products | Functional | Fetch product catalog | 200, data array with name/price/in_stock |
| MTC-API-06 | POST /carts/:id | Functional | Add product to cart | 201, cart_items contains added product with correct qty |
| MTC-API-07 | POST /invoices | Functional | Generate invoice from cart | 200/201, invoice_number and status in body |

---

## Coverage Summary

| Category | Count |
|----------|-------|
| Functional (UI) | 5 |
| Negative (UI) | 3 |
| Edge Case (UI) | 2 |
| API (reference) | 7 |
| **Total** | **17** |

Automated coverage targets the @smoke and @regression tagged cases above.  
Remaining cases are suitable for exploratory / manual execution sessions.
